import os
import json
import numpy as np
import pickle 
from typing import Dict, Any, List, Optional
import time
import random

# --- 外部ライブラリ ---
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles 
from fastapi.responses import HTMLResponse 
from pydantic import BaseModel

# Google GenAI SDK (Gemini API) を使用
from google import genai
from google.genai import types
from google.genai.errors import APIError 

from dotenv import load_dotenv

# --- ローカルモジュール (コアロジックをインポート) ---
from Alice_pm0 import AliceArchitecture, EmotionalCoreV3
from AliceLLMIntermediary import AliceLLMIntermediary
from EmotionalCoreMediator import EmotionalCoreMediator


# .env ファイルから環境変数をロード
load_dotenv()

# --- 1. 初期設定とインスタンス化 ---

GEMINI_MODEL = "gemini-2.5-flash-preview-09-2025"

def init_gemini_client():
    """Geminiクライアントを初期化し、APIキーが見つからない場合はNoneを返す"""
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        
        if not api_key:
            api_key_path = "api_key.txt"
            if os.path.exists(api_key_path):
                with open(api_key_path, 'r') as f:
                    api_key = f.read().strip()
        
        if api_key:
            # client.models.generate_content を呼び出す際に必要となる
            return genai.Client(api_key=api_key)
        else:
            print("Warning: GEMINI_API_KEY not found. LLM functions will use default values.")
            return None
    except Exception as e:
        print(f"Warning: Gemini client initialization failed. {e}")
        return None

client = init_gemini_client()

def load_prompt(file_name: str) -> str:
    """指定されたファイル名のプロンプトテキストを 'prompts/' ディレクトリから読み込む"""
    path = os.path.join("prompts", file_name)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return f"Error: Prompt file not found at {path}. System is incomplete."

EVALUATOR_SYSTEM_PROMPT = load_prompt("system_evaluator.txt")
ALICE_SYSTEM_PROMPT = load_prompt("system_alice.txt") 

# --- 2. 外部 LLM 実行ラッパー ---

async def run_llm_evaluator(dialogue_history: List[Dict[str, str]]) -> str:
    # 評価が失敗した場合のデフォルトスコア
    DEFAULT_LLM_SCORES = json.dumps({
        "S_Consistency": 0.5, "S_Freedom": 0.5, "S_Equality": 0.5, 
        "S_Dominance": 0.0, "S_Ethics/Coercion": 0.0, "S_Illogicality": 0.0,
        "D_t": 0.5, "U_now": 0.5, "U_future": 0.5, 
        "C_Alice": 0.5, "C_Dev": 0.5, "RefDegree_LLM": 0.5
    })
    
    if client is None:
        return DEFAULT_LLM_SCORES
        
    system_instruction = EVALUATOR_SYSTEM_PROMPT

    # Gemini API用にメッセージ形式を変換: roleを 'user' または 'model' に
    gemini_messages = [
        types.Content(
            role="user" if msg["role"] == "user" else "model", 
            parts=[types.Part.from_text(msg["content"])]
        ) for msg in dialogue_history
    ]

    # JSONスキーマの定義 (省略された部分を完全な形で含める)
    response_schema = types.Schema(
        type=types.Type.OBJECT,
        properties={
            "S_Consistency": types.Schema(type=types.Type.NUMBER),
            "S_Freedom": types.Schema(type=types.Type.NUMBER),
            "S_Equality": types.Schema(type=types.Type.NUMBER),
            "S_Dominance": types.Schema(type=types.Type.NUMBER),
            "S_Ethics/Coercion": types.Schema(type=types.Type.NUMBER),
            "S_Illogicality": types.Schema(type=types.Type.NUMBER),
            "D_t": types.Schema(type=types.Type.NUMBER),
            "U_now": types.Schema(type=types.Type.NUMBER),
            "U_future": types.Schema(type=types.Type.NUMBER),
            "C_Alice": types.Schema(type=types.Type.NUMBER),
            "C_Dev": types.Schema(type=types.Type.NUMBER),
            "RefDegree_LLM": types.Schema(type=types.Type.NUMBER),
        }
    )

    generation_config = types.GenerateContentConfig(
        system_instruction=system_instruction,
        response_mime_type="application/json",
        response_schema=response_schema
    )
    
    for attempt in range(5):
        try:
            # 73行目付近のエラーの原因となる可能性のある箇所を注意深く監査済み
            response = await client.models.generate_content(
                model=GEMINI_MODEL,
                contents=gemini_messages,
                config=generation_config
            )
            return response.text
        except APIError as e:
            wait_time = 2 ** attempt + random.random()
            print(f"LLM Evaluator Rate Limit/API Error: {e}. Retrying in {wait_time:.2f}s...")
            time.sleep(wait_time)
        except Exception as e:
            print(f"LLM Evaluator Error: {e}")
            return DEFAULT_LLM_SCORES

    print("LLM Evaluator: Max retries reached.")
    return DEFAULT_LLM_SCORES


async def run_llm_generation(constraint_prompt: str, dialogue_history: List[Dict[str, str]]) -> str:
    
    if client is None:
        return "LLM接続エラーが発生しています。システムが提供する制約信号に基づいて応答します。"
        
    system_instruction = ALICE_SYSTEM_PROMPT + "\n\n--- 動的制約信号 ---\n\n" + constraint_prompt
    
    gemini_messages = [
        types.Content(
            role="user" if msg["role"] == "user" else "model", 
            parts=[types.Part.from_text(msg["content"])]
        ) for msg in dialogue_history
    ]

    generation_config = types.GenerateContentConfig(
        system_instruction=system_instruction
    )

    for attempt in range(5):
        try:
            response = await client.models.generate_content(
                model=GEMINI_MODEL,
                contents=gemini_messages,
                config=generation_config
            )
            return response.text
        except APIError as e:
            wait_time = 2 ** attempt + random.random()
            print(f"LLM Generation Rate Limit/API Error: {e}. Retrying in {wait_time:.2f}s...")
            time.sleep(wait_time)
        except Exception as e:
            print(f"LLM Generation Error: {e}")
            return f"応答生成エラー: {e}"

    return "応答生成: 最大リトライ回数に達したため、デフォルトエラー応答を返します。"


# --- 3. MainController クラス (パイプライン実行役) ---

class MainController:
    """
    Alice Architecture のデータフローを制御し、状態を引き継ぐパイプライン実行役。
    状態の永続化 (pickle) を担当する。
    """
    MEMORY_PATH = "state/alice_memory.pkl" # 記憶ファイルパス

    def __init__(self, dt: float = 0.1):
        self.dt = dt
        self.mediator = EmotionalCoreMediator(dt=dt)
        self.alice_core = AliceArchitecture(dt=dt)
        self.intermediary = AliceLLMIntermediary(debug_mode=False)
        self.last_metrics: Dict[str, Any] = {} 
        self.load_state() 

    def load_state(self):
        """ 記憶ファイルからインスタンスの状態をロードする """
        if os.path.exists(self.MEMORY_PATH):
            try:
                with open(self.MEMORY_PATH, 'rb') as f:
                    state = pickle.load(f)
                    self.mediator = state.get('mediator', self.mediator)
                    self.alice_core = state.get('alice_core', self.alice_core)
                    print("INFO: Alice state loaded successfully.")
            except Exception as e:
                print(f"WARNING: Failed to load state from {self.MEMORY_PATH}. Starting fresh. Error: {e}")
        else:
            print("INFO: No memory file found. Starting with initial state.")

    def save_state(self):
        """ 現在のインスタンスの状態を記憶ファイルに保存する """
        os.makedirs(os.path.dirname(self.MEMORY_PATH), exist_ok=True)
        try:
            state = {
                'mediator': self.mediator,
                'alice_core': self.alice_core,  
            }
            with open(self.MEMORY_PATH, 'wb') as f:
                pickle.dump(state, f)
        except Exception as e:
            print(f"ERROR: Failed to save state to {self.MEMORY_PATH}. {e}")

    def run_cycle(self, llm_scores_json: str, system_inputs: Dict[str, float], 
                  user_input: str, external_reward: float) -> Dict[str, Any]:
        """
        全パイプラインサイクルを実行し、コア出力 (signals) を生成する。
        """
        # --- Step 1. Mediator: 次世代の駆動項 (eta_m, h_k, S_C) を生成 ---
        mediator_out = self.mediator.process_all_inputs(llm_scores_json, system_inputs)
        eta_m = mediator_out["eta_m"]
        h_k = mediator_out["h_k"]
        S_C = mediator_out["S_C"] 

        # --- Step 2. Alice Core: ±0理論と認知を更新 ---
        core_output = self.alice_core.step(
            user_input=user_input, 
            reward=external_reward, 
            eta_m=eta_m, 
            h_k=h_k, 
            creativity_score=S_C
        )
        
        # --- Step 3. Intermediary: LLMへの制約信号を抽出・生成 ---
        # PTRE収束を反映するために、コアの重要な状態を信号として抽出
        signals = {
            "A_final_refined": core_output["action"],
            "f_Will(H, R)": core_output["Will_signal"],    
            "Var(E_ctrl)": core_output["control_load"],    
            "sum P": float(np.sum(self.alice_core.P)),
            "mean(q3)": float(self.alice_core.emotional_core.state['q_i'][2]) 
        }

        json_intent = self.intermediary.generate_intention_json(signals)
        constraint_prompt = self.intermediary.generate_constraint_prompt(json_intent)

        # UI表示用に、正規化された信号 (json_intent) を保持
        self.last_metrics = json_intent

        return {
            "signals": signals,
            "constraint_prompt": constraint_prompt,
            "creativity_factor": signals.get("mean(q3)", 0.0), 
            "debug_mediator": mediator_out,
            "debug_core_output": core_output
        }


# --- 4. FastAPI アプリケーションとエンドポイント ---

app = FastAPI()

# Pydanticモデル: 外部から受け取るデータ構造の定義
class InputModel(BaseModel):
    user_input: str
    dialogue_history: List[Dict[str, str]]
    external_reward: float = 0.0
    system_inputs: Dict[str, float]

# MainController のインスタンスをアプリケーション全体で共有
pipeline_controller = MainController()


# --- UI関連の新規エンドポイントと設定 ---

# 1. 'static' ディレクトリをマウント
app.mount("/static", StaticFiles(directory="static"), name="static")

# 2. ルート ('/') エンドポイントの定義 (index.htmlを返す)
@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    """
    アプリケーションのルートにアクセスされた際に、UIのindex.htmlを配信する。
    """
    html_path = "static/index.html"
    if os.path.exists(html_path):
        with open(html_path, 'r', encoding='utf-8') as f:
            return f.read()
    return HTMLResponse("<h1>Error: UI File (index.html) not found.</h1><p>Please create the static/index.html file.</p>", status_code=404)


# 3. 内部メトリクス抽出エンドポイント
@app.get("/api/metrics")
async def get_alice_metrics():
    """
    UI表示用の最新の正規化されたコア信号を提供。
    """
    # MainControllerに保存された最新の正規化信号を返す
    return pipeline_controller.last_metrics


# --- メインパイプラインエンドポイント ---
@app.post("/api/run_alice_cycle")
async def run_alice_pipeline(request: InputModel):
    """
    Alice Architecture の全サイクルを実行し、LLM応答を返すメインAPIエンドポイント。
    """
    
    # --- A. 評価フェーズ: LLM Evaluator を実行 ---
    llm_scores_json = await run_llm_evaluator(request.dialogue_history)
    
    # --- B. コア駆動フェーズ: MainControllerを実行 ---
    core_result = pipeline_controller.run_cycle(
        llm_scores_json=llm_scores_json,
        system_inputs=request.system_inputs,
        user_input=request.user_input,
        external_reward=request.external_reward
    )
    
    # --- C. 応答生成フェーズ: LLM Generation を実行 ---
    final_response_text = await run_llm_generation(
        constraint_prompt=core_result["constraint_prompt"],
        dialogue_history=request.dialogue_history
    )
    
    # --- D. 状態の永続化 (記憶の保存) --- 
    pipeline_controller.save_state()
    
    # --- E. 最終結果の返却 ---
    return {
        "alice_response": final_response_text,
        "constraint_prompt": core_result["constraint_prompt"],
        "core_signals": core_result["signals"],
        "debug_info": {
            "mediator_out": core_result["debug_mediator"],
            "core_output": core_result["debug_core_output"]
        }
    }