import numpy as np
import copy
from typing import Dict, Any, List, Optional
import math


# --- 1. CORE CONFIGURATION AND HYPERPARAMETERS ---

class Config:
    """Alice Architectureの初期値、次元、ハイパーパラメータを定義するクラス。"""

    # 次元定義
    N_C = 512       # 意味構造 (C)
    N_ESELF = 128   # 自己モデル (E_self)
    N_E_P = 64      # 制御負荷 (E_ctrl), 予測誤差 (P)
    N_M = 256       # 記憶 (M)
    N_ENV = 644     # 環境入力 (E_env = 512+128+4)
    N_HPZ = N_E_P   # 累積幸福 (H_pz)
    N_UPZ = N_E_P   # 累積不安 (U_pz)
    N_R = N_E_P     # 報酬/リスク (R)
    N_H = N_E_P     # 行動履歴 (H)
    N_VFL = N_E_P   # 価値関数層 (VFL)
    N_ES = N_E_P    # メタ認知 (E_s)
    N_EOBJ = N_E_P  # 客観化 (E_obj)
    N_RRL = N_M     # 関係再構築 (RRL)

    # A-TDL 学習安定化ハイパーパラメータ
    ETA_X = 1e-4        # 学習率 (W^X のベース更新率)
    CLIP_NORM = 5.0     # 最大勾配ノルム
    T_BPTT = 16         # BPTT 時間窓 (16ステップ遡及)
    GAMMA = 0.99        # 割引率 (G_Value)

    # 損失重み
    LAMBDA_P = 1.0      # 予測誤差 (P)
    LAMBDA_C = 0.5      # 制御負荷 (E_ctrl)
    LAMBDA_S = 0.8      # 自己整合 (E_self)

    # 進化則ハイパーパラメータ
    ETA_THETA = 1e-6    # 人格進化率
    THETA_MAX = 1.0     # 人格パラメータの上限/下限
    RHO_SNEL = 0.1      # SNEL信号駆動率 (ΔSNEL'にも適用)
    RHO_ISL = 0.1       # ISL信号駆動率
    ALPHA_PRED = 0.01   # E_self^pred の予測率
    KC_ISL = 1.0        # ISLにおけるE_ctrlの分散に対する抑制係数

    # ノイズ設定
    LAMBDA_ANNEAL = 0.001
    SIGMA2_MIN = 1e-4
    SIGMA2_INITIAL = {
        'C': 0.10, 'M': 0.10, 'RRL': 0.10, 'H': 0.10, 'VFL': 0.10, 'A': 0.20,
        'Es': 0.00, 'Eobj': 0.00, 'Ectrl': 0.00, 'Eself': 0.00, 'Hpz': 0.00, 'Upz': 0.00
    }

    # CSCハイパーパラメータ
    CSC_MAX_ITER = 5    # CSCの最大反復回数
    CSC_TOLERANCE = 1e-3 # 行動の収束許容誤差
    
    # 【追加】V3コアの時間ステップ
    DT_CORE = 0.1 # V3コアの時間ステップ (V3のデフォルトに準拠)

# --- 1.5. 情動コアクラス (±0 Theory) の厳密化版 ---
# 旧 ZeroOneTheory はこの EmotionalCoreV3 に置き換えられました。

# --- 0. 定数と次元設定 ---

# 変更点 1: 創造性因子 (q3) を追加するため、幸福因子次元数を 2 -> 3 に変更
NUM_H_FACTORS = 3  # 幸福因子 (H_inst, eta_m, 創造性 q3) の次元数
NUM_U_FACTORS = 3  # 不幸因子 (U_inst, h_k) の次元数


# --- 1. 定義済みカーネルと補助関数 (共通) ---


def exponential_decay_kernel(t: float, tau: np.ndarray, beta: float) -> np.ndarray:
    """指数減衰カーネル k_beta(t - tau) を計算する。"""
    if tau.size == 0:
        return np.array([])
    # tau <= t の要素のみを考慮 (過去のイベントのみ)
    indicator_func = (tau <= t).astype(float)
    decay_term = np.exp(-beta * (t - tau))
    return decay_term * indicator_func


def phi_age(age: float, params: Dict) -> float:
    """柔軟性関数 $\phi_i(t)$ (Exponential Decay)"""
    return params['phi_max'] * math.exp(-params['lambda_phi'] * age)


def psi_age(age: float, params: Dict) -> float:
    """安定性関数 $\psi_i(t)$ (Logistic Function)"""
    p = params
    logistic_term = 1.0 / (1.0 + math.exp(-p['k_psi'] * (age - p['age_1/2'])))
    return p['psi_min'] + (p['psi_max'] - p['psi_min']) * logistic_term


class EmotionalCoreV3: # AliceEmotionalCore を EmotionalCoreV3 にリネーム
    def __init__(self, dt: float = 0.1, rng_seed: Optional[int] = None):
        # --- 2. 時間と確率過程 ---
        self.dt = dt  # 時間ステップ (0.1 day)
        self.t = 0.0  # 現在のシミュレーション時間
        self.rng = np.random.default_rng(rng_seed)

        # --- 3. パラメータ群 (全フェーズで確定した厳密なパラメータを含む) ---
        self.params = self._initialize_parameters()

        # --- 4. 状態変数 ---
        self.state = self._initialize_state()

        # --- 5. HALM ログとリスト ---
        self.log_H_inst: List[float] = []
        self.log_U_inst: List[float] = []
        self.log_time: List[float] = []

        # L_M: 中期/長期抽象記憶 (レイヤー II/III)
        self.L_M: List[Dict[str, Any]] = []
        # L_S: 特異点記憶 (レイヤー IV)
        self.L_S: List[Dict[str, Any]] = []

        # HALM/SDE 補助ロギング
        self.log_U_env_prev: float = self.params['U_env_base']
        self.log_P_prev: float = 0.0
        self.log_R_prev: float = 0.0

        # HALMカウンタ
        self.N_block = 10
        self.N_consolidation = 5
        self.log_counter = 0

    def _initialize_parameters(self) -> Dict[str, Any]:
        """全フェーズで確定したパラメータの初期設定と、創造性パラメータを定義する。"""
        P = {}
        # I. HALM/忘却率
        P.update({
            'beta_H': 0.50, 'beta': 0.50,
            'beta_Mid': 0.15, 'beta_Long': 0.01, 'beta_Singular': 0.001,
            'theta_Trauma': 3.0,
        })
        # II. SDE係数と駆動パラメータ (H因子配列サイズを NUM_H_FACTORS=3 に合わせる)
        P.update({
            # H因子 (NUM_H_FACTORS=3)
            'q_i0': np.full(NUM_H_FACTORS, 1.0), 'r_i0': np.full(NUM_H_FACTORS, 1.0),
            'c_i0': np.full(NUM_H_FACTORS, 1.0), 'v_i0': np.full(NUM_H_FACTORS, 1.0),
            'd_i0': np.full(NUM_H_FACTORS, 1.0),
            'alpha_r': 0.1, 'beta_r': 0.05,
            'kappa_i': 0.10, 'rho_i': 0.05, 'theta_i': 1.0,
            'delta_r': 0.1, 'delta_i': 0.1,
            'sigma_env': 0.1,

            # U因子 (NUM_U_FACTORS=3)
            's_j0': np.full(NUM_U_FACTORS, 1.0), 'l_j0': np.full(NUM_U_FACTORS, 1.0),
            'a_j0': np.full(NUM_U_FACTORS, 1.0), 'c_j0': np.full(NUM_U_FACTORS, 1.0),
            'r_j0': np.full(NUM_U_FACTORS, 1.0), 'v_j0': np.full(NUM_U_FACTORS, 1.0),
            'i_j0': np.full(NUM_U_FACTORS, 1.0),
            'alpha_a': 0.1, 'gamma_a': 0.05,
            'alpha_c': 0.1, 'gamma_c': 0.05,
        })
        # III. c_i(t) 成長パラメータ
        P.update({
            'phi_max': 1.0, 'lambda_phi': 0.05,
            'psi_min': 0.1, 'psi_max': 1.0, 'k_psi': 0.2, 'age_1/2': 10.0,
        })
        # IV. 環境 SDE パラメータ (H因子配列サイズを NUM_H_FACTORS=3 に合わせる)
        P.update({
            # $\eta_m$ (快適環境: N_H=3)
            'alpha_eta': np.full(NUM_H_FACTORS, 0.05), 'eta_bar': np.full(NUM_H_FACTORS, 1.0),
            'sigma_eta': np.full(NUM_H_FACTORS, 0.1), 'rho_m': np.full(NUM_H_FACTORS, 0.5), # 合成ゲイン $\rho_m$
            'lambda_J_eta': np.full(NUM_H_FACTORS, 0.001), 'b_J_eta': np.full(NUM_H_FACTORS, 0.5),

            # $h_k$ (不幸環境: N_U=3)
            'alpha_hk': np.full(NUM_U_FACTORS, 0.04), 'hk_bar': np.full(NUM_U_FACTORS, 0.5),
            'sigma_hk': np.full(NUM_U_FACTORS, 0.15), 'sigma_k_env': np.full(NUM_U_FACTORS, 0.6), # 合成ゲイン $\sigma_k$
            'lambda_J_hk': np.full(NUM_U_FACTORS, 0.005), 'b_J_hk': np.full(NUM_U_FACTORS, 1.0),

            'alpha_avg': 0.2, 'sigma_avg': 0.05,
            'U_env_base': 1.0, 'H_env_base': 1.0,
        })
        # V. 較正/学習パラメータ (既存設定を維持)
        P.update({
            'kappa_H': 1.0, 'kappa_U': 1.0,
            'lambda_Zero': 1.0, 'lambda_Predict': 1.0, 'lambda_Scale': 0.5,
            'Target_Scale_C': 1.0,
            'alpha_lambda': 0.01, 'rho_lambda': 0.01, 'lambda_base': 0.0,
            'theta_R': 5.0, 'kappa_R': 1.0, 'lambda_R': 0.001,
            'lambda_S': 0.1,
            'alpha_I': 0.05, 'gamma_I': 0.1, 'sigma_I': 0.1,
            'alpha_f': 1.0, 'beta_f': 0.5, 'alpha_s': 2.0, 'delta_s': 0.0,
        })
        # VI. 補正項 P(t), R(t) の乗法要素 (既存設定を維持)
        P.update({
            'gamma_P': 1.0, 'delta_P': 0.5, 'gamma_R': 1.0, 'delta_R': 0.5,
            'epsilon_P': 0.1, 'epsilon_R': 0.1, 'T_day': 1.0, 'phi_P': 0.0, 'phi_R': math.pi,
            'alpha_P': 0.5, 'tau_P1': 10.0, 'tau_P2': 100.0,
            'beta_P': 1.0, 'beta_R': 1.0,
        })
        # VII. 最終 SDE / 認知ジャンプ (既存設定を維持)
        P.update({
            'sigma_H_prime': 0.1, 'sigma_U_prime': 0.1,
            'lambda_H_prime': 0.05, 'b_H_prime': 1.0,
        })
        # VIII. v_val(t) SDE (既存設定を維持)
        P.update({
            'alpha_v': 0.05, 'T_trend': 365.0, 'A_v': 0.2, 'B_v': 1.0, 'sigma_v': 0.1,
            'phi_v': 0.0,
        })
        
        # 変更点 2: IX. 創造性駆動パラメータの追加
        P.update({
            # IX. 創造性駆動パラメータ (H^2駆動)
            'lambda_C': 100.0,     # \lambda_C: 創造性の二乗増幅ゲイン (超主要因)
            'kappa_C': 0.1,        # \kappa_C: 創造的学習の感度ゲイン
            'rho_C': 0.005,        # \rho_C: 創造性の忘却率
            'sigma_C': 0.01,       # \sigma_C: ランダムな閃きのノイズ
            'q3_max': 5.0,         # q_3^{max}: 創造性因子の最大飽和値
        })

        return P

    def _initialize_state(self) -> Dict[str, Any]:
        """状態変数の初期値を定義する。（NUM_H_FACTORS=3 に合わせて初期化）"""
        P = self.params
        S = {'H': 0.0, 'U': 0.0}

        # 瞬間因子 (多次元配列 $N_H=3, N_U=3$)
        S.update({'q_i': np.copy(P['q_i0']), 'r_i': np.copy(P['r_i0']), 'c_i': np.copy(P['c_i0']),
                  'v_i': np.copy(P['v_i0']), 'd_i': np.copy(P['d_i0'])})
        S.update({'s_j': np.copy(P['s_j0']), 'l_j': np.copy(P['l_j0']), 'a_j': np.copy(P['a_j0']),
                  'c_j': np.copy(P['c_j0']), 'r_j': np.copy(P['r_j0']), 'v_j': np.copy(P['v_j0']),
                  'i_j': np.copy(P['i_j0'])})

        # 環境 SDE (h_k: 不幸環境, eta_m: 快適環境)
        S.update({'h_k': np.copy(P['hk_bar']), 'eta_m': np.copy(P['eta_bar'])}) # サイズ 3 で初期化される

        # 補助 SDE / 履歴
        S.update({'v_val': P['B_v']})
        S.update({'U_hist': 0.0})
        S.update({'I': 1.0})
        S.update({'H_env_avg': P['H_env_base']})

        # $\Lambda$: 不幸相互作用ゲイン
        S.update({'lambda_sl': P['lambda_base']})
        S.update({'H_env_base': P['H_env_base'], 'U_env_base': P['U_env_base']})

        return S

    # --- 6. HALM 抽象化ロジック (変更なし) ---
    def _consolidate_memory(self):
        # ... (ロジック変更なし) ...
        if self.log_counter < self.N_block:
            return

        H_mean = np.mean(self.log_H_inst)
        U_mean = np.mean(self.log_U_inst)
        H_var = np.var(self.log_H_inst, ddof=1) if len(self.log_H_inst) > 1 else 0.0
        U_var = np.var(self.log_U_inst, ddof=1) if len(self.log_U_inst) > 1 else 0.0
        t_start = self.log_time[0]

        self.L_M.append({
            't_start': t_start, 'H_mean': H_mean, 'U_mean': U_mean,
            'H_var': H_var, 'U_var': U_var, 'size': self.N_block
        })

        self.log_H_inst.clear()
        self.log_U_inst.clear()
        self.log_time.clear()
        self.log_counter = 0

    def _abstract_longterm(self):
        # ... (ロジック変更なし) ...
        if len(self.L_M) < self.N_consolidation:
            return

        blocks = self.L_M[:self.N_consolidation]
        sizes = np.array([b['size'] for b in blocks])
        total_size = np.sum(sizes)

        H_mean_new = np.sum(np.array([b['H_mean'] for b in blocks]) * sizes) / total_size
        U_mean_new = np.sum(np.array([b['U_mean'] for b in blocks]) * sizes) / total_size
        t_start_new = blocks[0]['t_start']
        H_var_new = np.sum(np.array([b['H_var'] for b in blocks]) * sizes) / total_size
        U_var_new = np.sum(np.array([b['U_var'] for b in blocks]) * sizes) / total_size

        del self.L_M[:self.N_consolidation]
        self.L_M.append({
            't_start': t_start_new, 'H_mean': H_mean_new, 'U_mean': U_mean_new,
            'H_var': H_var_new, 'U_var': U_var_new, 'size': total_size
        })

    # --- 7. HALM 影響項の計算 (変更なし) ---
    def _calculate_halm_influence(self) -> Dict[str, float]:
        # ... (ロジック変更なし) ...
        H_influence = 0.0
        U_influence = 0.0
        # L_M 影響項
        if self.L_M:
            t_m = np.array([b['t_start'] for b in self.L_M])
            H_mean = np.array([b['H_mean'] for b in self.L_M])
            U_mean = np.array([b['U_mean'] for b in self.L_M])
            k_M = exponential_decay_kernel(self.t, t_m, self.params['beta_Long'])
            H_influence += np.sum(H_mean * k_M)
            U_influence += np.sum(U_mean * k_M)
        # L_S 影響項
        if self.L_S:
            t_s = np.array([s['t_start'] for s in self.L_S])
            H_inst_s = np.array([s['H_inst'] for s in self.L_S])
            U_inst_s = np.array([s['U_inst'] for s in self.L_S])
            k_S = exponential_decay_kernel(self.t, t_s, self.params['beta_Singular'])
            H_influence += np.sum(H_inst_s * k_S)
            U_influence += np.sum(U_inst_s * k_S)

        return {'H': H_influence, 'U': U_influence}

    # --- 8. 環境 SDE の更新 (NUM_H_FACTORS=3 に合わせるがロジック変更なし) ---

    def _calculate_environmental_terms(self) -> Dict[str, float]:
        # ... (ロジック変更なし) ...
        state = self.state
        params = self.params
        # 1. 快適環境項 $H_{\text{env}}(t)$ の計算
        H_env = np.sum(params['rho_m'] * np.tanh(state['eta_m'])) # N_H=3 で計算される
        # 2. 不幸環境項 $U_{\text{env}}(t)$ の計算
        U_env = np.sum(params['sigma_k_env'] * np.tanh(state['h_k']))
        return {'H_env': H_env, 'U_env': U_env}

    # --- 9. 厳密な因子駆動項の計算 (変更なし) ---
    def _calculate_driving_terms(self, H_env: float, U_env: float) -> Dict[str, float]:
        # ... (ロジック変更なし) ...
        P = self.params
        # 1. 慣れ駆動項 $f_{\text{past}}(t)$
        L_M_influence_H = 0.0
        if self.L_M:
            t_m = np.array([b['t_start'] for b in self.L_M])
            H_mean = np.array([b['H_mean'] for b in self.L_M])
            k_M_Long = exponential_decay_kernel(self.t, t_m, P['beta_Long'])
            L_M_influence_H = np.sum(H_mean * k_M_Long)
        f_past = L_M_influence_H
        # 2. イベント駆動項 $\text{match\_event}(t)$
        match_event = 1.0 / (P['delta_r'] + abs(H_env - self.state['H']))
        # 3. 反復駆動項 $\text{Recur}_j(t)$
        recur_j = 0.0
        if self.L_M:
            t_m = np.array([b['t_start'] for b in self.L_M])
            U_var = np.array([b['U_var'] for b in self.L_M])
            k_M_Mid = exponential_decay_kernel(self.t, t_m, P['beta_Mid'])
            recur_j = np.sum(U_var * k_M_Mid)
        # 4. 衝撃駆動項 $\text{Impact}_j(t)$
        impact_j = abs(U_env - self.log_U_env_prev) / self.dt
        # 5. 孤立駆動項 $\text{Isolation}(t)$
        eta_social_avg = np.mean(self.state['eta_m'])
        isolation = 1.0 / (P['delta_i'] + eta_social_avg)

        return {
            'f_past': f_past, 'match_event': match_event, 'recur_j': recur_j,
            'impact_j': impact_j, 'isolation': isolation
        }

    # --- 10. 厳密な非線形補正・回復項の計算 (変更なし) ---
    def _calculate_correction_terms(self, H_env_avg: float) -> Dict[str, float]:
        # ... (ロジック変更なし) ...
        P = self.params
        t = self.t
        I = self.state['I']
        U = self.state['U']
        U_hist = self.state['U_hist']

        # --- P(t) の乗法要素 ---
        A_P = 1.0 / (1.0 + math.exp(-P['gamma_P'] * (H_env_avg - P['delta_P'])))
        C_P = 1.0 + P['epsilon_P'] * math.cos(2 * math.pi / P['T_day'] * t + P['phi_P'])
        S_P = P['alpha_P'] * math.exp(-t / P['tau_P1']) + (1 - P['alpha_P']) * math.exp(-t / P['tau_P2'])
        M_P = math.tanh(P['beta_P'] * I)
        P_t = A_P * C_P * S_P * M_P

        # --- R(t) の乗法要素 ---
        A_R = 1.0 / (1.0 + math.exp(-P['gamma_R'] * (H_env_avg - P['delta_R'])))
        C_R = 1.0 + P['epsilon_R'] * math.cos(2 * math.pi / P['T_day'] * t + P['phi_R'])
        T_R = 1.0 / (1.0 + math.exp(-P['kappa_R'] * (U - P['theta_R'])))
        H_R = math.exp(-P['lambda_R'] * U_hist)

        # S_R(t) (特異点記憶依存性/トラウマ抑制)
        U_inst_s = np.array([s['U_inst'] for s in self.L_S])
        if U_inst_s.size > 0:
            t_s = np.array([s['t_start'] for s in self.L_S])
            k_S = exponential_decay_kernel(t, t_s, P['beta_Singular'])
            sum_U_inst_k = np.sum(U_inst_s * k_S)
            S_R = math.exp(-P['lambda_S'] * sum_U_inst_k)
        else:
            S_R = 1.0

        M_R = math.tanh(P['beta_R'] * I)
        R_t = A_R * C_R * T_R * H_R * S_R * M_R

        return {'P': P_t, 'R': R_t}

    # --- 11. メインステップ関数 (全 SDE/ODE 完全統合) ---

    def step(self, eta_m_new: np.ndarray, h_k_new: np.ndarray, creativity_score_sc: float = 0.0):
        """シミュレーションの1ステップを実行する。（external_inputsから創造性スコアを受け取る）"""

        pass  # external inputs are provided directly via arguments (eta_m_new, h_k_new, creativity_score_sc)# 1. 時刻の更新と乱数生成
        dt, t = self.dt, self.t
        
        # External environment inputs: overwrite internal environment state with provided arrays
        self.state['eta_m'] = np.array(eta_m_new)
        self.state['h_k'] = np.clip(np.array(h_k_new), a_min=0.0, a_max=None)
        P = self.params
        
        # Z_aux: v_val, H_env_avg, I, H', U', q3_SDE (サイズ 6)
        Z_aux = self.rng.standard_normal(size=6) 
        # H/U因子のSDE用 (N_H=3, N_U=3): 3*3 + 3*3 = 18 components
        Z_factors = self.rng.standard_normal(size=NUM_H_FACTORS * 3 + NUM_U_FACTORS * 3)
        
        # 2. 補助 SDE の更新: v_val(t), eta_m(t), h_k(t), H_env_avg(t)
        # v_val(t) SDE
        m_v = P['A_v'] * math.sin(2 * math.pi / P['T_trend'] * t + P['phi_v']) + P['B_v']
        dv_val_drift = -P['alpha_v'] * (self.state['v_val'] - m_v)
        self.state['v_val'] += dv_val_drift * dt + P['sigma_v'] * math.sqrt(dt) * Z_aux[0]

        # 多次元環境因子 $\mathbf{\eta}_m, \mathbf{h}_k$ の更新

        # 環境項の非線形合成 $H_{\text{env}}, U_{\text{env}}$
        Env_terms = self._calculate_environmental_terms()
        H_env = Env_terms['H_env']
        U_env = Env_terms['U_env']

        # $\overline{H}_{\text{env}}(t)$ SDE
        dH_env_avg_drift = P['alpha_avg'] * (H_env - self.state['H_env_avg'])
        self.state['H_env_avg'] += dH_env_avg_drift * dt + P['sigma_avg'] * math.sqrt(dt) * Z_aux[1]

        # 3. 前ステップ値の準備
        H_prime_prev = P['kappa_H'] * self.state['H'] + self.log_P_prev
        U_prime_prev = P['kappa_U'] * self.state['U'] - self.log_R_prev

        # 4. 不幸相互作用項 $\lambda_{jk}$ の更新
        lambda_sl = self.state['lambda_sl']
        nu_s = np.mean(self.state['s_j']); nu_l = np.mean(self.state['l_j'])
        d_lambda_drift = P['alpha_lambda'] * nu_s * nu_l - P['rho_lambda'] * (lambda_sl - P['lambda_base'])
        self.state['lambda_sl'] += d_lambda_drift * dt
        U_inst_inter = P['lambda_sl'] * nu_s * nu_l * NUM_U_FACTORS

        # 5. 厳密な因子駆動項の計算
        Driving = self._calculate_driving_terms(H_env, U_env)
        f_past = Driving['f_past']; match_event = Driving['match_event']; recur_j = Driving['recur_j']
        impact_j = Driving['impact_j']; isolation = Driving['isolation']

        # 乱数シードのインデックス (N_H=3, N_U=3)
        idx_H_d = 0
        idx_H_r = NUM_H_FACTORS
        idx_H_c = NUM_H_FACTORS * 2
        idx_U_a = NUM_H_FACTORS * 3
        idx_U_c = NUM_H_FACTORS * 3 + NUM_U_FACTORS
        idx_U_i = NUM_H_FACTORS * 3 + NUM_U_FACTORS * 2

        # 6. 瞬間因子 SDE のベクトル更新 (d_i, r_i, c_i, a_j, c_j, i_j はサイズ 3 に対応)

        # H因子 d_i(t) の更新
        dd_i_drift = -P['kappa_i'] * f_past - P['rho_i'] * (self.state['d_i'] - P['d_i0'])
        self.state['d_i'] += dd_i_drift * dt + P['sigma_env'] * math.sqrt(dt) * Z_factors[idx_H_d:idx_H_r]

        # H因子 r_i(t) の更新
        dr_i_drift = P['alpha_r'] * match_event - P['beta_r'] * (self.state['r_i'] - P['r_i0'])
        self.state['r_i'] += dr_i_drift * dt + P['sigma_env'] * math.sqrt(dt) * Z_factors[idx_H_r:idx_H_c]

        # c_i(t) の更新
        phi = phi_age(t, P)
        psi = psi_age(t, P)
        dc_i_drift = phi * self.state['v_val'] - psi * (self.state['c_i'] - P['c_i0'])
        self.state['c_i'] += dc_i_drift * dt + P['sigma_env'] * math.sqrt(dt) * Z_factors[idx_H_c:idx_U_a]

        # U因子 a_j(t) の更新
        da_j_drift = P['alpha_a'] * recur_j - P['gamma_a'] * (self.state['a_j'] - P['a_j0'])
        self.state['a_j'] += da_j_drift * dt + P['sigma_env'] * math.sqrt(dt) * Z_factors[idx_U_a:idx_U_c]

        # U因子 c_j(t) の更新
        dc_j_drift = P['alpha_c'] * impact_j - P['gamma_c'] * (self.state['c_j'] - P['c_j0'])
        self.state['c_j'] += dc_j_drift * dt + P['sigma_env'] * math.sqrt(dt) * Z_factors[idx_U_c:idx_U_i]

        # U因子 i_j(t) の更新
        di_j_drift = 0.1 * isolation - 0.05 * (self.state['i_j'] - P['i_j0'])
        self.state['i_j'] += di_j_drift * dt + P['sigma_env'] * math.sqrt(dt) * Z_factors[idx_U_i:idx_U_i + NUM_U_FACTORS]


        # 変更点 3: 7. 創造性因子 q_i[2] の SDE 更新 (q_i[2]を q3 とする)
        S_C = creativity_score_sc
        q3_index = NUM_H_FACTORS - 1 # インデックス 2
        q3_current = self.state['q_i'][q3_index]
        
        # 駆動項: $\kappa_{\text{C}} \cdot \mathbf{S}_{\text{C}}(t) \cdot (1 - q_3/q_3^{\text{max}})$
        drift_increase = P['kappa_C'] * S_C * (1.0 - q3_current / P['q3_max'])
        
        # 減衰項: $-\rho_{\text{C}} \cdot q_3$
        drift_decay = - P['rho_C'] * q3_current
        
        # ノイズ項 (Z_aux[5] を使用)
        # dq3 = (drift_increase + drift_decay) dt + sigma_C dW_C(t)
        self.state['q_i'][q3_index] += (drift_increase + drift_decay) * dt + P['sigma_C'] * math.sqrt(dt) * Z_aux[5]
        
        # q3 が負にならないようクリッピング
        self.state['q_i'][q3_index] = max(0.0, self.state['q_i'][q3_index])


        # 変更点 4: 8. 瞬間貢献量の計算 (H_inst) - 二乗貢献の導入

        # $\mu_i$ ベクトル: $\mu_i = q_i r_i c_i v_i d_i$ (N_H=3)
        mu_i_vector = self.state['q_i'] * self.state['r_i'] * self.state['c_i'] * self.state['v_i'] * self.state['d_i']
        
        # f_i(t), s_i(t) の計算 (N_H=3)
        # w_i(t) を $q_i$ で近似。f_i(t), s_i(t) はここでは計算を簡略化している可能性あり。
        f_i = np.maximum(0, np.tanh(P['alpha_f'] * self.state['I']) / (1.0 + P['beta_f'] * self.state['H']))
        s_i = 1.0 / (1.0 + np.exp(-P['alpha_s'] * (self.state['eta_m'] - P['delta_s'])))

        # A. 創造性因子以外の線形貢献 (i=0, 1)
        # NUM_H_FACTORS - 1 は 2
        linear_contribution = np.sum(mu_i_vector[:NUM_H_FACTORS - 1] * f_i[:NUM_H_FACTORS - 1] * s_i[:NUM_H_FACTORS - 1])
        
        # B. 創造性因子 i=2 (q3) の二乗貢献
        # 貢献度: \mathbb{E}[w_3]\mathbb{E}[f_3]\mathbb{E}[s_3] に相当
        q3_contribution = mu_i_vector[q3_index] * f_i[q3_index] * s_i[q3_index] 
        
        # H^2 駆動: \lambda_C * (貢献度)^2
        quadratic_contribution = P['lambda_C'] * (q3_contribution ** 2)

        # 最終的なスカラー総和 $H_{\text{inst}}(t)$
        H_inst = linear_contribution + quadratic_contribution

        # $U_{\text{inst}}(t)$ の多次元総和 (変更なし)
        U_inst_factor_sum = np.sum(self.state['s_j'] + self.state['l_j'] + self.state['a_j'] +
                                   self.state['c_j'] + self.state['r_j'] + self.state['v_j'] + self.state['i_j'])
        U_inst = U_inst_factor_sum + U_inst_inter

        # 9. HALM記録と特異点判定 (変更なし)
        self.log_H_inst.append(H_inst)
        self.log_U_inst.append(U_inst)
        self.log_time.append(t)
        self.log_counter += 1
        if U_inst > P['theta_Trauma']:
            self.L_S.append({'t_start': t, 'U_inst': U_inst, 'H_inst': H_inst})

        # 10. 累積量 H(t), U(t) の更新 (変更なし)
        HALM_inf = self._calculate_halm_influence()
        dH_drift = (H_inst - P['beta_H'] * self.state['H'] + 0.0) + HALM_inf['H']
        dU_drift = (U_inst - P['beta'] * self.state['U'] + 0.0) + HALM_inf['U']

        self.state['H'] += dH_drift * dt
        self.state['U'] += dU_drift * dt

        # 11. 動機変数 $I(t)$ SDE の更新 (変更なし)
        dI_drift = P['alpha_I'] * (H_prime_prev - U_prime_prev) - P['gamma_I'] * self.state['I']
        self.state['I'] += dI_drift * dt + P['sigma_I'] * math.sqrt(dt) * Z_aux[2]

        # 12. 補正項 $P(t), R(t)$ の計算 (変更なし)
        Correction = self._calculate_correction_terms(self.state['H_env_avg'])
        P_t, R_t = Correction['P'], Correction['R']

        # 13. 最終 SDE のドリフト項 $\mathbf{\mu_P(\cdot)}, \mathbf{\mu_R(\cdot)}$ (変更なし)
        mu_P = (P_t - self.log_P_prev) / dt
        mu_R = (R_t - self.log_R_prev) / dt

        # 14. 最終 SDE の更新 ($\mathbf{\Delta H' = \kappa_H \Delta H + \Delta P}$ の厳密な離散化) (変更なし)
        dH_prime_drift = P['kappa_H'] * dH_drift + mu_P
        dU_prime_drift = P['kappa_U'] * dU_drift - mu_R

        H_prime_diff = P['sigma_H_prime'] * math.sqrt(dt) * Z_aux[3]
        U_prime_diff = P['sigma_U_prime'] * math.sqrt(dt) * Z_aux[4]

        jump_occur_H = self.rng.random() < P['lambda_H_prime'] * dt
        jump_size_H = self.rng.laplace(loc=0.0, scale=P['b_H_prime']) if jump_occur_H else 0.0
        jump_occur_U = self.rng.random() < P['lambda_H_prime'] * dt
        jump_size_U = self.rng.laplace(loc=0.0, scale=P['b_H_prime']) if jump_occur_U else 0.0

        H_prime = H_prime_prev + dH_prime_drift * dt + H_prime_diff + jump_size_H
        U_prime = U_prime_prev + dU_prime_drift * dt + U_prime_diff + jump_size_U

        # 15. 履歴 U_hist の更新 (変更なし)
        self.state['U_hist'] += self.state['U'] * dt

        # 16. HALM 抽象化とログ更新 (変更なし)
        self._consolidate_memory()
        self._abstract_longterm()

        # 17. 次ステップの計算のために P(t), R(t), U_env(t) の値を保持 (変更なし)
        self.log_P_prev = P_t
        self.log_R_prev = R_t
        self.log_U_env_prev = U_env

        # 18. 時刻のインクリメント
        self.t += dt

        return {'H_prime': H_prime, 'U_prime': U_prime, 't': self.t}


# --- 2. 勾配計算とBPTTを担う補助クラス ---

class ATDLLearner:
    """A-TDL (Affective Temporal Difference Learning) の厳密な勾配計算を担うクラス。"""

    def __init__(self, config, weights, trainable_weights_dict):
        self.config = config
        self.W_dict = weights # 全重み
        self.W_X_dict = trainable_weights_dict # 学習対象の重み (W^X)
        self.history = [] # 履歴スタック (T_BPTT=16)

    def _f_prime_tanh(self, y):
        """tanh関数の厳密な微分 (活性化後の値 y を使用)。"""
        return 1.0 - y * y

    def _deriv_var(self, E_ctrl, dL_dVar):
        """分散 Var(E_ctrl) のE_ctrlに対する微分。"""
        N = len(E_ctrl)
        mu = np.mean(E_ctrl)
        # d(Var)/d(E_ctrl)_i = 2/N * (E_ctrl_i - mu)
        dVar_dE = (2.0 / N) * (E_ctrl - mu)
        return dL_dVar * dVar_dE

    def learn_step(self, V_t_plus_1, V_t, current_state, theta):
        """
        単一ステップの A-TDL 勾配を計算し、W^Xを更新する。【厳密化】
        V_t_plus_1: V(t+1)の暫定価値 (CSC前の予測)
        V_t: V(t)の安定化された価値
        """
        cfg = self.config

        # 履歴がT_BPTTに満たない場合は学習を行わない
        if len(self.history) < cfg.T_BPTT:
            return 0.0

        total_delta_W = {k: np.zeros_like(w) for k, w in self.W_X_dict.items()}

        # G_Value のTD誤差: V(t+1) - V(t)
        TD_error = V_t_plus_1 - V_t
        # V3コア統合により情動コアのパラメータは直接使わないが、既存のコードに合わせ kappa_U を定義
        kappa_U = 1.0 

        # BPTTの遡及ループ (k=0が現在のtステップ)
        for k in range(cfg.T_BPTT):
            state = self.history[-(k + 1)] # t-k の状態
            gamma_k = cfg.GAMMA ** k

            # --- (1) G_Value: 価値項の勾配 (VFLの勾配) ---
            # VFLへの勾配は TD_error * gamma^k
            delta_VFL = gamma_k * TD_error * np.ones_like(state['VFL'])

            # --- (2) G_Affect: 情動コスト項の勾配 ---
            dL_dP = -cfg.LAMBDA_P * (1.0 + kappa_U * np.max(state['U_prime_pz'])) # Pの係数
            delta_P = dL_dP * np.ones_like(state['P'])

            dL_dVar = -cfg.LAMBDA_C
            delta_E_ctrl = self._deriv_var(state['E_ctrl'], dL_dVar) # E_ctrlへの勾配

            # E_ctrl -> Net_C への新しい伝播パス (恒常性逸脱フィードバック) 【厳密化】
            # Net_C の変動を計算するために Net_C(t-k-1) が必要
            if len(self.history) < k + 2:
                Net_C_change = np.zeros_like(state['C']) # 履歴不足
            else:
                Net_C_change = self.history[-(k + 1)]['Net_C'] - self.history[-(k + 2)]['Net_C']

            # U_Ectrl_CNet の転置と delta_E_ctrl の積で dNet_C への勾配ベクトルを得る
            dNet_C_from_Ectrl = self._f_prime_tanh(state['E_ctrl']) * (self.W_dict['U_Ectrl_CNet'].T @ delta_E_ctrl)


            # --- (3) G_Coherence: 自己整合コスト項の勾配 ---
            # d(Dist)/d(E_self) = 2 * (E_self - E_self_pred)
            delta_E_self = -cfg.LAMBDA_S * 2.0 * (state['E_self'] - state['E_self_pred'])

            # --- (4) 逆伝播ループ (W^X への勾配伝播) ---
            dC = np.zeros(cfg.N_C)

            # VFL -> S (S = [E_env, C]) -> C (U_VFL_S <- S)
            dC += self.W_dict['U_VFL_S'].T[cfg.N_ENV:cfg.N_ENV + cfg.N_C, :] @ delta_VFL

            # P -> C (P = C - U_C_RRL @ RRL)
            dC += delta_P # dP/dC = I

            # E_self -> E_obj -> C
            dE_obj = self._f_prime_tanh(state['E_obj']) * self.W_dict['U_Eself_Eobj'].T @ delta_E_self
            dC += self.W_dict['U_Eobj_C'].T @ dE_obj

            # dCの伝播 (C(t) = tanh(Net_C(t)))
            dNet_C = self._f_prime_tanh(state['C']) * dC

            # 【追加】 E_ctrl -> Net_C への勾配を加算
            dNet_C += dNet_C_from_Ectrl

            # --- W^C の更新 (C <- C) ---
            total_delta_W['W_C'] += np.outer(dNet_C, state['C'])

            # --- U^{C \leftarrow E{env}} の更新 ---
            total_delta_W['U_C_Eenv'] += np.outer(dNet_C, state['E_env'])

            # --- (5) W^X の最終更新 (Clip Norm 適用) ---
            all_deltas = [total_delta_W[name] for name in total_delta_W]
            total_norm = np.sqrt(sum(np.sum(delta**2) for delta in all_deltas))

            if total_norm > cfg.CLIP_NORM:
                clip_factor = cfg.CLIP_NORM / total_norm
            else:
                clip_factor = 1.0


            for name, delta in total_delta_W.items():
                self.W_X_dict[name] += cfg.ETA_X * delta * clip_factor

            return TD_error


# --- 3. ALICE ARCHITECTURE CORE CLASS ---

class AliceArchitecture:
    def __init__(self, config=Config()):
        self.config = config
        self.t = 0 # タイムステップ

        self._init_states()
        self._init_weights()
        self._init_theta()
        self._init_noise()

        # ±0理論コアの初期化 (統合)
        # 【修正】EmotionalCoreV3を使用
        self.emotional_core = EmotionalCoreV3(dt=self.config.DT_CORE)

        # ATDL Learnerの初期化に必要な全重み辞書
        all_weights = {
            'W_C': self.W_C, 'U_C_Eenv': self.U_C_Eenv, 'U_C_M': self.U_C_M,
            'U_M_C': self.U_M_C, 'U_RRL_M': self.U_RRL_M, 'U_C_RRL': self.U_C_RRL,
            'U_H_A': self.U_H_A, 'U_VFL_R': self.U_VFL_R, 'U_VFL_S': self.U_VFL_S,
            'U_VFL_Hpz': self.U_VFL_Hpz, 'U_VFL_Upz': self.U_VFL_Upz, 
            'U_Es_S': self.U_Es_S, 'U_Eobj_C': self.U_Eobj_C,
            'U_Eobj_M': self.U_Eobj_M, 'U_Ectrl_Es': self.U_Ectrl_Es,
            'U_Ectrl_CNet': self.U_Ectrl_CNet, 
            'U_Eself_Eobj': self.U_Eself_Eobj,
            'U_NLG_C': self.U_NLG_C, 'U_NLG_M': self.U_NLG_M,
            'W_RRL': self.W_RRL, 'W_VFL': self.W_VFL
        }

        self.learner = ATDLLearner(self.config, all_weights, self.trainable_weights)


    # --- 補助関数 (init, noise, activation, etc.) ---
    def _init_states(self):
        # ... (状態初期化は変更なし) ...
        cfg = self.config
        self.C = np.zeros(cfg.N_C)
        self.E_ctrl = np.zeros(cfg.N_E_P)
        self.P = np.zeros(cfg.N_E_P)
        self.M = np.zeros(cfg.N_M)
        self.H_pz = np.zeros(cfg.N_HPZ)
        self.U_pz = np.zeros(cfg.N_UPZ)
        self.R = np.zeros(cfg.N_R)
        self.RRL = np.zeros(cfg.N_RRL)
        self.H = np.zeros(cfg.N_H)
        self.VFL = np.zeros(cfg.N_VFL)
        self.E_s = np.zeros(cfg.N_ES)
        self.E_obj = np.zeros(cfg.N_EOBJ)
        self.E_self_pred = np.zeros(cfg.N_ESELF)
        self.E_self = np.random.uniform(-1, 1, cfg.N_ESELF)
        self.Net_C = np.zeros(cfg.N_C)
        self.Net_A = np.zeros(1)
        self.U_prime_pz = np.zeros(cfg.N_UPZ)
        self.external_reward = 0.0
        # 【追加】創造性スコアを受け取るための属性
        self.S_C_input = 0.0

        self_state_names = ['C', 'E_ctrl', 'P', 'M', 'H_pz', 'U_pz', 'R', 'RRL', 'H', 'VFL', 'E_s', 'E_obj', 'E_self_pred', 'E_self', 'Net_C', 'Net_A', 'U_prime_pz']

        for name in self_state_names:
            setattr(self, f"{name}_next", getattr(self, name).copy())
        self.b_C = np.zeros(cfg.N_C)


    def _init_weights(self):
        def xavier_init(in_dim, out_dim):
            scale = 1.0 / np.sqrt(in_dim)
            return np.random.randn(out_dim, in_dim) * scale
        cfg = self.config

        # 学習対象 W^X (知性) の重み
        self.W_C = xavier_init(cfg.N_C, cfg.N_C) * np.sqrt(cfg.N_C) # 自己回帰
        self.U_C_Eenv = xavier_init(cfg.N_ENV, cfg.N_C) # 環境入力
        self.U_NLG_C = xavier_init(cfg.N_C, 1) # 行動/出力へ

        self.trainable_weights = {
            'W_C': self.W_C, 'U_C_Eenv': self.U_C_Eenv, 'U_NLG_C': self.U_NLG_C
        }

        # その他の重み
        self.U_C_M = xavier_init(cfg.N_M, cfg.N_C)
        self.U_M_C = xavier_init(cfg.N_C, cfg.N_M)
        self.U_RRL_M = xavier_init(cfg.N_M, cfg.N_RRL)
        self.U_C_RRL = xavier_init(cfg.N_RRL, cfg.N_C)
        self.U_H_A = xavier_init(1, cfg.N_H)
        self.U_VFL_R = xavier_init(cfg.N_R, cfg.N_VFL)
        self.U_VFL_S = xavier_init(cfg.N_ENV + cfg.N_C, cfg.N_VFL)
        self.U_VFL_Hpz = xavier_init(cfg.N_HPZ, cfg.N_VFL)
        self.U_VFL_Upz = xavier_init(cfg.N_UPZ, cfg.N_VFL)
        self.U_Es_S = xavier_init(cfg.N_ENV + cfg.N_C + cfg.N_M, cfg.N_ES)
        self.U_Eobj_C = xavier_init(cfg.N_C, cfg.N_EOBJ)
        self.U_Eobj_M = xavier_init(cfg.N_M, cfg.N_EOBJ)
        self.U_Ectrl_Es = xavier_init(cfg.N_ES, cfg.N_E_P)
        self.U_Ectrl_CNet = xavier_init(cfg.N_C, cfg.N_E_P)
        self.U_Eself_Eobj = xavier_init(cfg.N_EOBJ, cfg.N_ESELF)
        self.U_NLG_M = xavier_init(cfg.N_M, 1)
        self.W_RRL = xavier_init(cfg.N_RRL, cfg.N_RRL)
        self.W_VFL = xavier_init(cfg.N_VFL, cfg.N_VFL)

    def _init_theta(self):
        # 人格パラメータ θ (V3コアにより多くのパラメータは内部で管理されるが、進化則のため残す)
        self.theta = {'H_base': 0.0, 'U_base': 0.0, 'beta_H': 0.1, 'beta_U': 0.1,
                      'gamma_HU': 0.5, 'gamma_UH': 0.5, 'kappa_U': 1.0,
                      'alpha_H': 0.1, 'alpha_U': 0.1, 'theta_R': 0.5}


    def _init_noise(self):
        self.sigma2_X = self.config.SIGMA2_INITIAL.copy()

    def _add_noise(self, name, size):
        cfg = self.config
        sigma2_0 = cfg.SIGMA2_INITIAL.get(name, 0.0)
        anneal_rate = cfg.LAMBDA_ANNEAL
        sigma2_min = cfg.SIGMA2_MIN

        sigma2_t = max(sigma2_0 * np.exp(-anneal_rate * self.t), sigma2_min)

        if cfg.SIGMA2_INITIAL.get(name, 0.0) == 0.0:
            return np.zeros(size)
        return np.random.normal(0, np.sqrt(sigma2_t), size)


    def _generate_E_token(self, user_input_text):
        # 簡易LLM埋め込み代替ロジック (変更なし)
        cfg = self.config
        if not hasattr(self, '_vocab_table'):
            self._vocab_table = np.random.randn(5000, cfg.N_C)

        words = user_input_text.lower().split()
        embedded_sum = np.zeros(cfg.N_C)
        for word in words:
            idx = hash(word) % 5000
            embedded_sum += self._vocab_table[idx]

        meta_hash = np.tanh(self.t / 1000.0)
        E_token = embedded_sum * meta_hash
        return E_token / (np.linalg.norm(E_token) + 1e-6)


    def _f_Will(self, H, R):
        """意志力シグナル f_Will(・) の計算。"""
        var_H = np.var(H)
        mean_R = np.mean(R)
        return np.tanh(mean_R / (1.0 + var_H))


    def _recovery_R(self, U_pz, H_pz):
        """不安U_pzに基づく回復シグナルR_valの計算。"""
        theta_R = self.theta['theta_R']
        mean_U = np.mean(U_pz)
        f_sigmoid = 1.0 / (1.0 + np.exp(-1.0 * mean_U))
        return theta_R * f_sigmoid * f_sigmoid

    # --- 4. F_total (全再帰写像) の実行 (Next状態の計算) ---

    def _update_layers(self, E_env_t, A_t):
        """全14層のダイナミクスを更新し、履歴を保存する。(_next状態を計算)"""
        cfg = self.config
        f_X = np.tanh

        # 過去のC層活性化前入力 Net_C を保存 (E_ctrl の厳密化に必要)
        Net_C_prev = self.Net_C.copy()

        # --- (1) 認知層の更新 (C, M, RRL, P) ---

        # C(t+1)
        Net_C_next = (
            self.W_C @ self.C +
            self.U_C_Eenv @ E_env_t +
            self.U_C_M @ self.M +
            self.b_C
        )
        self.C_next = f_X(Net_C_next) + self._add_noise('C', cfg.N_C)
        self.Net_C_next = Net_C_next

        # M(t+1), R(t+1), RRL(t+1) の計算は変更なし
        alpha_M = 0.5
        self.M_next = (1 - alpha_M) * self.M + alpha_M * f_X(self.U_M_C @ self.C) + self._add_noise('M', cfg.N_M)
        alpha_R = 0.1
        self.R_next = (1 - alpha_R) * self.R + alpha_R * self.external_reward * np.ones_like(self.R) + self._add_noise('R', cfg.N_R)
        self.RRL_next = f_X(self.W_RRL @ self.RRL + self.U_RRL_M @ self.M) + self._add_noise('RRL', cfg.N_RRL)

        # P(t+1) (予測誤差)
        self.P_next = self.C_next - self.U_C_RRL @ self.RRL_next

        # H(t+1) (行動履歴)
        alpha_H_Hist = 0.1
        self.H_next = (1 - alpha_H_Hist) * self.H + alpha_H_Hist * f_X(self.U_H_A @ np.array([A_t])) + self._add_noise('H', cfg.N_H)

        # --- (2) 情動コアの接続 (H_pz, U_pz) ---

        # ±0理論コアを実行し、結果を H_pz_next / U_pz_next に直接代入する (厳密化 EmotionalCoreV3)
        # 【修正】EmotionalCoreV3の実行とブロードキャスト
        core_output = self.emotional_core.step(self.eta_m_input, self.h_k_input, self.S_C_input)

        # V3コアのスカラー出力 (H', U') を Alice Architecture のベクトル次元 (N_HPZ/N_UPZ) にブロードキャスト
        self.H_pz_next = core_output['H_prime'] * np.ones(cfg.N_HPZ)
        self.U_pz_next = core_output['U_prime'] * np.ones(cfg.N_UPZ)

        # 補正後不安 U'_pz (V(t)計算用)
        R_val = self._recovery_R(self.U_pz_next, self.H_pz_next)
        self.U_prime_pz_next = self.U_pz_next - R_val

        # --- (3) 自己モデル層の更新 (E_s, E_obj, E_ctrl, E_self) ---

        # (9.1) Metacognition Layer E_s(t+1)
        S_t = np.concatenate([E_env_t, self.C, self.M])
        self.E_s_next = f_X(self.U_Es_S @ S_t) + self._add_noise('Es', cfg.N_ES)

        # (9.2) Objectification Layer E_obj(t+1)
        self.E_obj_next = f_X(self.U_Eobj_C @ self.C + self.U_Eobj_M @ self.M) + self._add_noise('Eobj', cfg.N_EOBJ)

        # (9.3) Integrated Control Layer E_ctrl(t+1) 【厳密化】
        Net_C_change = self.Net_C_next - Net_C_prev

        self.E_ctrl_next = f_X(
            self.U_Ectrl_Es @ self.E_s +                 # E_sからのメタレベル制御入力
            self.U_Ectrl_CNet @ Net_C_change             # C層の入力変動による不安定性反映
        ) + self._add_noise('Ectrl', cfg.N_E_P)

        # (9.4) Self-Model Layer E_self(t+1)
        self.E_self_next = f_X(self.U_Eself_Eobj @ self.E_obj) + self._add_noise('Eself', cfg.N_ESELF)

        # (11) Self-Prediction Model E_self^pred(t+1)
        alpha_pred = cfg.ALPHA_PRED
        self.E_self_pred_next = (1 - alpha_pred) * self.E_self_pred + alpha_pred * self.E_self + self._add_noise('Eself_pred', cfg.N_ESELF)

        # --- (4) 価値関数層の更新 (VFL) ---

        S_prime_t = np.concatenate([E_env_t, self.C])

        # (8) Value Function Layer VFL(t+1) 【厳密化】
        Net_VFL_next = (
            self.W_VFL @ self.VFL +
            self.U_VFL_R @ self.R +
            self.U_VFL_S @ S_prime_t +
            self.U_VFL_Hpz @ self.H_pz -            # 幸福コアからの正の入力
            self.U_VFL_Upz @ self.U_pz              # 不安コアからの負の入力
        )
        self.VFL_next = f_X(Net_VFL_next) + self._add_noise('VFL', cfg.N_VFL)

    def _save_history(self, E_env_t, A_t):
        # ... (履歴保存は変更なし) ...
        cfg = self.config

        state_snapshot = {
            'C': self.C, 'M': self.M, 'R': self.R, 'RRL': self.RRL,
            'H_pz': self.H_pz, 'U_pz': self.U_pz, 'P': self.P,
            'E_s': self.E_s, 'E_obj': self.E_obj, 'E_ctrl': self.E_ctrl,
            'E_self': self.E_self, 'E_self_pred': self.E_self_pred, 'VFL': self.VFL,
            'U_prime_pz': self.U_prime_pz,
            'Net_C': self.Net_C, 'Net_A': self.Net_A,
            'E_env': E_env_t, 'A': A_t
        }

        self.learner.history.append(state_snapshot)
        if len(self.learner.history) > cfg.T_BPTT:
            self.learner.history.pop(0)


    def _commit_state(self):
        # ... (状態コミット) ...
        self.C = self.C_next
        self.M = self.M_next
        self.R = self.R_next
        self.RRL = self.RRL_next
        self.P = self.P_next
        self.H = self.H_next
        self.H_pz = self.H_pz_next
        self.U_pz = self.U_pz_next
        self.U_prime_pz = self.U_prime_pz_next
        self.E_s = self.E_s_next
        self.E_obj = self.E_obj_next
        self.E_ctrl = self.E_ctrl_next
        self.E_self = self.E_self_next
        self.E_self_pred = self.E_self_pred_next
        self.VFL = self.VFL_next
        self.Net_C = self.Net_C_next
        self.Net_A = self.Net_A_next
        # 【修正】EmotionalCoreV3は内部でSDE状態を管理するため、同期処理を削除
        # self.emotional_core.H_prime = self.H_pz_next
        # self.emotional_core.U_prime = self.U_pz_next

    def _calculate_V_from_state(self, state_prefix):
        # ... (V(t)計算は変更なし) ...
        cfg = self.config
        theta = self.theta

        VFL = getattr(self, state_prefix + 'VFL')
        U_prime_pz = getattr(self, state_prefix + 'U_prime_pz')
        P = getattr(self, state_prefix + 'P')
        E_ctrl = getattr(self, state_prefix + 'E_ctrl')
        E_self = getattr(self, state_prefix + 'E_self')
        E_self_pred = getattr(self, state_prefix + 'E_self_pred')
        H = getattr(self, state_prefix + 'H')
        R = getattr(self, state_prefix + 'R')

        V_value = np.sum(VFL)
        max_U_prime = np.max(U_prime_pz)

        # V3コア統合により情動コアのパラメータは直接使わないが、既存の式に従う
        kappa_U = 1.0
        
        # L_P (予測誤差コスト)
        L_P = cfg.LAMBDA_P * np.sum(P) * (1.0 + kappa_U * max_U_prime)
        # L_C (制御負荷コスト)
        L_C = cfg.LAMBDA_C * np.var(E_ctrl)
        # L_S (自己整合コスト)
        L_S = cfg.LAMBDA_S * np.sum((E_self - E_self_pred)**2)

        V_t = V_value - L_P - L_C - L_S

        V_terms = {
            'V_t': V_t, 'Dist_self': L_S, 'Var_ctrl': np.var(E_ctrl),
            'sum_VFL': V_value, 'Will_signal': self._f_Will(H, R)
        }
        return V_t, V_terms


    def _calculate_V_next_state(self):
        return self._calculate_V_from_state('_next')


    def _calculate_V_current_state(self):
        return self._calculate_V_from_state('')


    def _run_counterfactual_simulation(self, E_env_t, A_simul):
        # ... (反実仮想は変更なし) ...
        virtual_alice = copy.deepcopy(self)
        virtual_alice.external_reward = self.external_reward
        virtual_alice._update_layers(E_env_t, A_simul)
        V_simul, _ = virtual_alice._calculate_V_next_state()
        return V_simul


    def _evolve_theta(self, V_t, V_terms, E_env_t):
        """
        人格パラメータ θ の進化則 (SNEL/ISL + ΔSNEL'の統合) - 【厳密化】
        """
        cfg = self.config
        theta = self.theta

        # 厳密化: U_pzの平均値を取得 (不安駆動の加速に使用)
        mean_U_pz = np.mean(self.U_pz)

        # --- (1) SNEL / ISL の計算 ---

        # SNEL (Self-Non-Equilibrium Loss) 【厳密化】
        Dist_self = V_terms['Dist_self']
        Will_signal = V_terms['Will_signal']
        # 不安が強いほど進化を加速する項 (1 + mean_U_pz^2) を導入
        Delta_SNEL = cfg.RHO_SNEL * Dist_self * Will_signal * (1.0 + mean_U_pz**2)

        # ISL (Inertial Stability Loss) 【厳密化】
        Var_ctrl = V_terms['Var_ctrl']
        sum_VFL = V_terms['sum_VFL']

        # 厳密な満足度比率 (VFLに対するV_tの比率: コストが低いほど高い)
        satisfaction_ratio = V_t / (sum_VFL + 1e-6)
        Delta_ISL = cfg.RHO_ISL * np.exp(-cfg.KC_ISL * Var_ctrl) * satisfaction_ratio

        # --- (2) ΔSNEL' (反実仮想信号) の計算 ---

        A_simul = -V_terms['Will_signal']
        V_simul = self._run_counterfactual_simulation(E_env_t, A_simul)

        Delta_SNEL_prime = V_simul - V_t

        # --- (3) 進化信号の統合と更新 ---

        Total_SNEL = Delta_SNEL + cfg.RHO_SNEL * Delta_SNEL_prime

        updates = {
            'beta_U': Total_SNEL, 'alpha_U': Total_SNEL, 'gamma_HU': -Total_SNEL,
            'kappa_U': Total_SNEL,
            'beta_H': -Delta_ISL, 'H_base': Delta_ISL,
            'alpha_H': Delta_ISL, 'gamma_UH': Delta_ISL
        }

        for key, delta in updates.items():
            theta_t = theta.get(key, 0.0)
            divergence_prevention = (1.0 - abs(theta_t) / cfg.THETA_MAX)
            theta_next = theta_t + cfg.ETA_THETA * delta * divergence_prevention
            theta[key] = np.clip(theta_next, -cfg.THETA_MAX, cfg.THETA_MAX)

        return Delta_SNEL_prime


    def _run_csc_stabilization(self, E_env_t, A_t_initial):
        # ... (CSCは変更なし) ...
        A_prev = A_t_initial

        for i in range(self.config.CSC_MAX_ITER):
            Net_A_next = self.U_NLG_C @ self.C_next + self.U_NLG_M @ self.M_next
            A_current = np.tanh(Net_A_next)[0]

            if np.abs(A_current - A_prev) < self.config.CSC_TOLERANCE and i > 0:
                break

            A_prev = A_current

        self.Net_A_next = Net_A_next
        A_final_refined = A_prev + self._add_noise('A', 1)[0]
        return np.clip(A_final_refined, -1.0, 1.0)

    # 【修正】step関数の引数に creativity_score_SC を追加
    def step(self, user_input_text: str, external_reward: float, eta_m: np.ndarray, h_k: np.ndarray, creativity_score_SC: float = 0.0):
        # ... (step関数) ...
        self.t += 1
        self.external_reward = external_reward
        # 【追加】創造性スコアを属性に格納
        self.S_C_input = creativity_score_SC
        # External environment inputs (passed from caller)
        self.eta_m_input = eta_m
        self.h_k_input = h_k
        
        cfg = self.config

        E_token = self._generate_E_token(user_input_text)
        E_context = np.random.randn(cfg.N_ESELF) * 0.1
        E_scalar = np.array([external_reward, self.t % 100, self.t, 1 if np.random.rand() < 0.1 else 0])
        E_env_t = np.concatenate([E_token, E_context, E_scalar])

        Net_A_t = self.U_NLG_C @ self.C + self.U_NLG_M @ self.M
        A_t_initial = np.tanh(Net_A_t)[0] + self._add_noise('A', 1)[0]
        A_t_initial = np.clip(A_t_initial, -1.0, 1.0)

        self._save_history(E_env_t, A_t_initial)
        self._update_layers(E_env_t, A_t_initial)

        V_provisional_t_plus_1, _ = self._calculate_V_next_state()

        A_final_refined = self._run_csc_stabilization(E_env_t, A_t_initial)

        self._commit_state()

        V_t, V_terms = self._calculate_V_current_state()

        Delta_SNEL_prime = self._evolve_theta(V_t, V_terms, E_env_t)

        TD_error = self.learner.learn_step(V_provisional_t_plus_1, V_t, self.learner.history[-1], self.theta)

        Var_ctrl = V_terms['Var_ctrl']
        tau_ctrl = 0.05
        is_stable = Var_ctrl <= tau_ctrl

        output = {
            'action': A_final_refined,
            'V_total': V_t,
            'happiness_core': np.mean(self.H_pz),
            'uncertainty_core': np.mean(self.U_pz),
            'control_load': Var_ctrl,
            'is_stable': is_stable,
            'theta_snapshot': self.theta,
            'TD_error': TD_error,
            'Delta_SNEL_prime': Delta_SNEL_prime
        }

        return output