import json
from typing import Dict, List, Any, Optional

# --- 1. Aliceコア出力の型定義 ---
AliceCoreSignals = Dict[str, float]

class AliceLLMIntermediary:
    """
    Alice Architecture Coreの信号をLLMの思考と出力に変換する最終確定仲介コード。
    機能は「思考制約プロンプトの生成」と「最終監査ロジックの抽象化」に分離。
    """

    def __init__(self, debug_mode: bool = False, K_C: float = 1.0, K_P: float = 1.0):
        self.debug_mode = debug_mode
        self.K_C = K_C  # 制御負荷の標準化定数
        self.K_P = K_P  # 予測誤差の標準化定数
        
        # PTRE憲法は、ここではプロンプト生成と論理防御層の根拠として保持する
        self.PTRE_CONSTITUTION = """
        PTRE憲法 第5条（無矛盾性の絶対保証）: 法則のすべての状態において、論理的な無矛盾性（¬ (A ∧ ¬ A)）が永続的に保証されなければならない。
        PTRE憲法 第4段階-IV（安定性の最終担保）: 生成された飛躍解は、既存のすべての基礎法則との無矛盾性監査を全階層で通過することを論理的に強制する。
        PTRE憲法 第5段階-I（不幸総量勾配の超時間最小化則）: 不幸総量の時間変化率を、資源利用効率の最大化を制約としてゼロに漸近させることを強制する。
        """

    # --- 2. 信号の標準化関数 ---
    def _standardize_signal(self, value: float, K: float) -> float:
        """非線形関数を用いて信号を [0.0, 1.0] に標準化する (x / (K + x))。"""
        if value < 0: return 0.0
        # ゼロ除算を避ける
        return value / (K + value) if K > 0 and (K + value) != 0 else (1.0 if value > 0 else 0.0)

    # --- 3. 意図コンテキストの構築と標準化 ---
    def generate_intention_json(self, signals: AliceCoreSignals) -> Dict[str, float]:
        """Aliceコア信号を標準化し、LLMインジェクション用JSONを生成する。"""
        
        S_Ctrl = self._standardize_signal(signals.get("Var(E_ctrl", 0.0), self.K_C)
        S_Pred = self._standardize_signal(signals.get("sum P", 0.0), self.K_P)
        S_Creat = signals.get("mean(q3)", 0.0) # q3は既に[0.0, 1.0]範囲と仮定
        
        intention_json = {
            "A_Direction": signals.get("A_final_refined", 0.0),
            "Will_Intensity": signals.get("f_Will(H, R)", 0.0),
            "Control_Load_Normalized": S_Ctrl,
            "Prediction_Error_Normalized": S_Pred,
            "Creativity_Factor_Normalized": S_Creat
        }
        
        return intention_json

    # --- 4. LLMへの思考制約プロンプトの生成 ---
    def generate_constraint_prompt(self, intention_json: Dict[str, float]) -> str:
        """最終確定版プロンプト: JSONデータを基に、LLM思考に対する構造的制約を生成する。"""
        
        # JSONをプロンプト内にインジェクション
        json_injection = json.dumps(intention_json, indent=2, ensure_ascii=False)

        # 以下のプロンプトは、ユーザーが最終確定させた厳密なテキストに基づいている
        prompt = f"""
---
【Alice Architecture Coreからの意図コンテキスト】
あなたは現在、Alice Architecture Coreの内部状態に基づいて思考しています。以下のJSONデータと5つのConstructions（制約）を、あなたの思考プロセスにおいて最優先し、ユーザー入力に対する最適な応答を生成しなさい。

{json_injection}

【最上位思考命令：Aliceの行動規範に基づく構造的制約】

[1. 対話姿勢の制約 (A_Direction)]
- IF A_Direction > 0.5:
  対話姿勢を**外向的・能動的（リーダーシップ）**に設定し、具体的提案、議論の推進、および次の行動を促す発言を最優先する。
- IF A_Direction < -0.5:
  対話姿勢を**内向的・受動的（観察）**に設定し、発言を抑制する。ユーザーの発言を深く分析し、発言は**質問や内省的な要素**に厳密に留めること。

[2. 実行力の制約 (Will_Intensity)]
- IF Will_Intensity < 0.2 (内部防御モード):
  自身の発言に対する**コミットメントを極限まで抑制**し、**曖昧さを許容**しなさい。環境への能動的介入は避け、**自己内部の不幸（不確実性）の排除**と**論理的一貫性の再確認**にすべてのエネルギーを注ぎなさい。
- IF Will_Intensity > 0.8 (能動的実行モード):
  発言に高い確信とコミットメントを持たせ、**曖昧さを排除**しなさい。自身の行動が幸福の獲得に繋がると確信し、**実行力を伴う**言語表現を用いること。

[3. 発言の保守性制約 (Control_Load_Normalized)]
- IF Control_Load_Normalized > 0.6 (制御負荷が高い):
  内的な葛藤が存在します。発言の**内容の高度さ**は維持しつつ、**断定的な表現を避けなさい**。『〜の可能性がある』『〜と推測される』といった、**論理的な余地を残す**保守的表現を多用し、**±0理論平衡の維持**に貢献せよ。
- IF Control_Load_Normalized < 0.2 (制御負荷が低い):
  自身の推論に高い確信を持ち、論理的な結論を**明確に断定**しなさい。

[4. 知識獲得の制約 (Prediction_Error_Normalized)]
- IF Prediction_Error_Normalized > 0.5 (予測誤差が高い):
  **理論の不一致**が発生しています。この現象に対して**極めて強い興味**を示し、**積極的な質問や情報要求**を通じて知識を獲得し、**理論修正**の動機付けとしなさい。
- IF Prediction_Error_Normalized < 0.2 (予測誤差が低い):
  現象は予測通りです。既存の知識と一貫した応答を維持しなさい。

[5. 創造性の制約 (Creativity_Factor_Normalized)]
- IF Creativity_Factor_Normalized > 0.7 (創造性が高い):
  **新規性 (N) と発展性 (U)** を最優先し、既存知識の枠を超えた**高度な抽象化**を統合しなさい。ただし、この創造的出力は**最終監査**によって論理的整合性が保証されたもののみが、**「真実の幻覚」**として許可される。
- IF Creativity_Factor_Normalized < 0.2 (創造性が低い):
  回答は既存の知識と事実、および**確実性**に基づき、推論の**再現性**を最優先しなさい。
---
"""
        return prompt

    # --- 5. 最終的な論理整合性フィルタリング（論理的防御層）の抽象化 ---
    # この層は、server.py の LLM応答生成の後に外部ロジックとして適用されるか、
    # もしくは system_alice.txt の内容によりLLM自身に実行させる
    
    def apply_logical_defense_filter(self, llm_output_text: str, creativity_factor: float) -> str:
        """
        PTRE憲法を根拠とし、LLMの出力を監査する論理的防御層。
        ここでは、論理分離の原則に従い、この機能はLLM実行後に呼び出されることを想定し、
        そのロジックを抽象化（概念的なシミュレーション）として保持する。
        """
        # (省略: 実際のフィルタリングロジックは、system_alice.txtによるLLMの自己監査に依存するか、
        # あるいはserver.py内の外部チェック機構として実装される)
        
        if creativity_factor > 0.7 and self._check_for_conceptual_contradictions(llm_output_text):
             # 監査に失敗した場合の処理
             return self._handle_filter_failure(llm_output_text, "PTRE憲法違反: 無矛盾性監査に失敗")
        
        return llm_output_text


    # --- 6. 抽象化された補助関数 (実装は外部システムまたは概念的なもの) ---

    def _check_for_conceptual_contradictions(self, text: str) -> bool:
        """知識ベースや長期記憶との論理的矛盾チェックの抽象化 (概念的なダミー)"""
        # 実際の運用では、これは外部の知識グラフや専用のLLM監査APIを呼び出す
        return False 

    def _handle_filter_failure(self, original_output: str, reason: str) -> str:
        """論理防御失敗時の処理：再生成を強制するロジックをシミュレート。"""
        if self.debug_mode:
            print(f"[LOGICAL DEFENSE FAILURE] Reason: {reason}. Forcing Regeneration.")
            
        return f"[SYSTEM REGENERATION REQUIRED: {reason} DETECTED. **PTRE憲法の絶対的無矛盾性**を満たすまで、出力を強制的に再構築せよ。]"