// static/app.js - Alice Core Logic Viewer 駆動スクリプト

const API_CHAT_ENDPOINT = "/api/run_alice_cycle";
const API_METRICS_ENDPOINT = "/api/metrics";

let dialogueHistory = []; // 会話履歴を保持 (サーバーへの送信に使用)

// --- 1. PTREコア信号のリアルタイム更新 ---
async function fetchMetrics() {
    try {
        const response = await fetch(API_METRICS_ENDPOINT);
        const metrics = await response.json();
        
        // 1. 標準ゲージ (0.0 ~ 1.0) の更新
        updateGauge('will', metrics.Will_Intensity);
        updateGauge('control', metrics.Control_Load_Normalized);
        updateGauge('prediction', metrics.Prediction_Error_Normalized); // 新規追加
        updateGauge('creativity', metrics.Creativity_Factor_Normalized);

        // 2. 双極性ゲージ (-1.0 ~ 1.0) の更新
        updateActionDirection(metrics.A_Direction); // 新規追加

        // 3. 状態メッセージの更新
        updateStateMessage(metrics);

    } catch (error) {
        console.error("Failed to fetch metrics:", error);
    }
}

/** * 標準ゲージ (0.0 - 1.0) を更新する関数 
 */
function updateGauge(idPrefix, value) {
    const valueEl = document.getElementById(`${idPrefix}-value`);
    const barEl = document.getElementById(`${idPrefix}-bar`);
    
    // 値を0.0から1.0の範囲にクランプ（念のため）
    const clampedValue = Math.max(0, Math.min(1, value));

    const percentage = (clampedValue * 100).toFixed(1);
    valueEl.textContent = percentage + '%';
    barEl.style.width = percentage + '%';
}

/**
 * Action Direction (-1.0 ~ 1.0) のインジケータを更新する特殊関数
 */
function updateActionDirection(value) {
    const valueEl = document.getElementById('action-direction-value');
    const indicatorEl = document.getElementById('action-direction-indicator');
    
    // 値を-1.0から1.0の範囲にクランプ
    const clampedValue = Math.max(-1.0, Math.min(1.0, value));

    // 値をテキストで表示
    valueEl.textContent = clampedValue.toFixed(3);

    // インジケータの位置を計算
    // -1.0 -> 0% (受動), 0.0 -> 50% (中立), 1.0 -> 100% (能動)
    const positionPercent = (clampedValue * 50) + 50; 
    indicatorEl.style.left = `${positionPercent}%`;
}

/**
 * 現在の状態メッセージを更新する関数
 */
function updateStateMessage(metrics) {
    const stateEl = document.getElementById('ptre-state');
    
    if (metrics.Creativity_Factor_Normalized > 0.8) {
        stateEl.textContent = "極限的創造性探索 (真実の幻覚プロトコル)";
        stateEl.style.color = "#9b59b6"; // 紫
    } else if (metrics.Control_Load_Normalized > 0.7) {
        stateEl.textContent = "内部葛藤高 (保守的防御モード)";
        stateEl.style.color = "#f1c40f"; // 黄
    } else if (metrics.Prediction_Error_Normalized > 0.7) {
        stateEl.textContent = "法則不一致 (情報要求モード)";
        stateEl.style.color = "#e74c3c"; // 赤
    } else if (metrics.Will_Intensity > 0.6) {
        stateEl.textContent = "高実行力 (コミットメント強制)";
        stateEl.style.color = "#2ecc71"; // 緑
    } else {
        stateEl.textContent = "恒常性維持モード (安定)";
        stateEl.style.color = "#ccc"; // グレー
    }
}

// 2秒ごとにメトリクスを更新
setInterval(fetchMetrics, 2000);


// --- 2. チャット送信ロジック ---
document.getElementById('chat-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const userInputEl = document.getElementById('user-input');
    const userMessage = userInputEl.value.trim();
    if (!userMessage) return;

    // 1. ユーザーメッセージを履歴に追加し、入力欄をクリア
    addMessageToHistory("user", userMessage);
    userInputEl.value = '';
    
    // 送信ボタンを無効化 (応答待ち)
    const submitButton = this.querySelector('button');
    submitButton.disabled = true;
    submitButton.textContent = '思考中...';

    // 2. サーバーへ送信するデータを作成
    dialogueHistory.push({ role: "user", content: userMessage });
    
    // システム入力（ここでは単純化）: 調整したい場合はこの値を変更
    const systemInputs = { reward_rate: 0.5, stability_index: 0.5 };
    const externalReward = 0.0; 

    const requestBody = {
        user_input: userMessage,
        dialogue_history: dialogueHistory,
        external_reward: externalReward,
        system_inputs: systemInputs
    };

    try {
        const response = await fetch(API_CHAT_ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });
        const result = await response.json();

        // 3. Aliceの応答とデバッグ情報を表示
        const aliceResponse = result.alice_response;
        const constraintPrompt = result.constraint_prompt;
        
        addMessageToHistory("alice", aliceResponse);
        dialogueHistory.push({ role: "model", content: aliceResponse });

        // 制約プロンプトをデバッグログに表示
        document.getElementById('constraint-log').textContent = constraintPrompt;
        
        // 最新のメトリクスを手動で更新 (即時フィードバック)
        fetchMetrics(); 

    } catch (error) {
        addMessageToHistory("system-error", "システムエラー: 応答を取得できませんでした。", true);
        console.error("Chat API Error:", error);
    } finally {
        // ボタンを再度有効化
        submitButton.disabled = false;
        submitButton.textContent = '送信';
    }
});

/**
 * 会話履歴にメッセージを追加する関数
 */
function addMessageToHistory(role, content, isError = false) {
    const historyEl = document.getElementById('dialogue-history');
    const msgEl = document.createElement('div');
    
    let roleText = role.charAt(0).toUpperCase() + role.slice(1);
    if (isError) {
        msgEl.className = `message system-error`;
        roleText = "ERROR";
    } else {
        msgEl.className = `message ${role}`;
    }
    
    msgEl.innerHTML = `<strong>[${roleText}]</strong>: ${content.replace(/\n/g, '<br>')}`;
    historyEl.appendChild(msgEl);
    
    // スクロールを最下部に移動
    historyEl.scrollTop = historyEl.scrollHeight;
}

// 初期メトリクス取得
fetchMetrics();