import os
import json
import numpy as np
import pickle
from typing import Dict, Any, List
import time
import random
import asyncio

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

from fastapi.encoders import jsonable_encoder

from google import genai
from google.genai import types
from google.genai.errors import APIError

from dotenv import load_dotenv

from Alice_pm0 import AliceArchitecture, EmotionalCoreV3
from AliceLLMIntermediary import AliceLLMIntermediary
from EmotionalCoreMediator import EmotionalCoreMediator

# ==============================================
# Load environment
# ==============================================
load_dotenv()
GEMINI_MODEL = "gemini-2.5-flash-preview-09-2025"


def init_gemini_client():
    """Initialize Gemini client, gracefully handle missing key."""
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            api_key_path = "api_key.txt"
            if os.path.exists(api_key_path):
                with open(api_key_path, "r", encoding="utf-8") as f:
                    api_key = f.read().strip()

        if api_key:
            return genai.Client(api_key=api_key)
        else:
            print("WARNING: GEMINI_API_KEY not found. LLM disabled.")
            return None
    except Exception as e:
        print(f"WARNING: Failed to initialize Gemini client: {e}")
        return None


client = init_gemini_client()


# ==============================================
# Prompt loaders
# ==============================================
def load_prompt(file_name: str) -> str:
    path = os.path.join("prompts", file_name)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return f"ERROR: Missing prompt at {path}"


EVALUATOR_SYSTEM_PROMPT = load_prompt("system_evaluator.txt")
ALICE_SYSTEM_PROMPT = load_prompt("system_alice.txt")


# ==============================================
# LLM evaluator
# ==============================================
async def run_llm_evaluator(dialogue_history: List[Dict[str, str]]) -> str:
    DEFAULT_SCORES = json.dumps({
        "S_Consistency": 0.5, "S_Freedom": 0.5, "S_Equality": 0.5,
        "S_Dominance": 0.0, "S_Ethics/Coercion": 0.0, "S_Illogicality": 0.0,
        "D_t": 0.5, "U_now": 0.5, "U_future": 0.5,
        "C_Alice": 0.5, "C_Dev": 0.5, "RefDegree_LLM": 0.5
    })

    if client is None:
        return DEFAULT_SCORES

    system_instruction = EVALUATOR_SYSTEM_PROMPT

    gemini_messages = [
        types.Content(
            role="user" if m["role"] == "user" else "model",
            parts=[types.Part(text=m["content"])]
        ) for m in dialogue_history
    ]

    response_schema = types.Schema(
        type=types.Type.OBJECT,
        properties={k: types.Schema(type=types.Type.NUMBER) for k in json.loads(DEFAULT_SCORES)}
    )

    config = types.GenerateContentConfig(
        system_instruction=system_instruction,
        response_mime_type="application/json",
        response_schema=response_schema
    )

    for attempt in range(5):
        try:
            response = await asyncio.to_thread(
                client.models.generate_content,
                model=GEMINI_MODEL,
                contents=gemini_messages,
                config=config
            )
            return response.text
        except APIError as e:
            wait = 2 ** attempt + random.random()
            print(f"[Evaluator] RateLimit: {e} Retry in {wait:.2f}s")
            time.sleep(wait)
        except Exception as e:
            print(f"[Evaluator] Error: {e}")
            return DEFAULT_SCORES

    return DEFAULT_SCORES


# ==============================================
# LLM generation
# ==============================================
async def run_llm_generation(constraint_prompt: str, dialogue_history: List[Dict[str, str]]) -> str:
    if client is None:
        return "LLM connection failed. Running internal constraints only."

    system_instruction = ALICE_SYSTEM_PROMPT + "\n\n--- Dynamic Constraint ---\n\n" + constraint_prompt

    gemini_messages = [
        types.Content(
            role="user" if msg["role"] == "user" else "model",
            parts=[types.Part(text=msg["content"])]
        ) for msg in dialogue_history
    ]

    config = types.GenerateContentConfig(system_instruction=system_instruction)

    for attempt in range(5):
        try:
            response = await asyncio.to_thread(
                client.models.generate_content,
                model=GEMINI_MODEL,
                contents=gemini_messages,
                config=config
            )
            return response.text
        except APIError as e:
            wait = 2 ** attempt + random.random()
            print(f"[Generation] RateLimit: {e} Retry in {wait:.2f}s")
            time.sleep(wait)
        except Exception as e:
            print(f"[Generation] Error: {e}")
            return f"Error generating response: {e}"

    return "Error: max retries exceeded"


# ==============================================
# Main controller
# ==============================================
class MainController:
    MEMORY_PATH = "state/alice_memory.pkl"

    def __init__(self, dt: float = 0.1):
        self.dt = dt
        self.mediator = EmotionalCoreMediator(dt=dt)
        self.alice_core = AliceArchitecture()
        self.intermediary = AliceLLMIntermediary(debug_mode=False)
        self.last_metrics: Dict[str, Any] = {}
        self.load_state()

    def load_state(self):
        if os.path.exists(self.MEMORY_PATH):
            try:
                with open(self.MEMORY_PATH, "rb") as f:
                    state = pickle.load(f)
                    self.mediator = state.get("mediator", self.mediator)
                    self.alice_core = state.get("alice_core", self.alice_core)
                    print("INFO: Memory loaded successfully.")
            except Exception as e:
                print(f"WARNING: Memory load failed: {e}")
        else:
            print("INFO: No previous state. Starting fresh.")

    def save_state(self):
        os.makedirs(os.path.dirname(self.MEMORY_PATH), exist_ok=True)
        try:
            with open(self.MEMORY_PATH, "wb") as f:
                pickle.dump({"mediator": self.mediator, "alice_core": self.alice_core}, f)
        except Exception as e:
            print(f"ERROR: Memory save failed: {e}")

    def run_cycle(self, llm_scores_json: str, system_inputs: Dict[str, float],
                  user_input: str, external_reward: float):

        mediator_out = self.mediator.process_all_inputs(llm_scores_json, system_inputs)

        core_output = self.alice_core.step(
            user_input_text=user_input,
            external_reward=external_reward,
            eta_m_new=mediator_out["eta_m_new"],
            h_k_new=mediator_out["h_k_new"],
            creativity_score_sc=mediator_out["creativity_score_sc"]
        )

        signals = {
            "A_final_refined": core_output["action"],
            "f_Will(H,R)": core_output["Will_signal"],
            "Var(E_ctrl)": core_output["control_load"],
            "sum P": float(np.sum(self.alice_core.P)),
            "mean(q3)": float(self.alice_core.emotional_core.state["q_i"][2])
        }

        json_intent = self.intermediary.generate_intention_json(signals)
        self.last_metrics = json_intent

        constraint_prompt = self.intermediary.generate_constraint_prompt(json_intent)

        return {
            "signals": signals,
            "constraint_prompt": constraint_prompt,
            "debug_mediator": mediator_out,
            "debug_core_output": core_output
        }


# ==============================================
# FastAPI setup
# ==============================================
app = FastAPI()


class InputModel(BaseModel):
    user_input: str
    dialogue_history: List[Dict[str, str]]
    external_reward: float = 0.0
    system_inputs: Dict[str, float]


pipeline_controller = MainController()

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    path = "static/index.html"
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    return HTMLResponse("<h1>Error: UI missing</h1>", status_code=404)


@app.get("/api/metrics")
async def get_metrics():
    return JSONResponse(content=pipeline_controller.last_metrics)


# ==============================================
# Main execution endpoint
# ==============================================
@app.post("/api/run_alice_cycle")
async def run_alice_cycle(request: InputModel):
    llm_scores = await run_llm_evaluator(request.dialogue_history)

    core_result = pipeline_controller.run_cycle(
        llm_scores_json=llm_scores,
        system_inputs=request.system_inputs,
        user_input=request.user_input,
        external_reward=request.external_reward
    )

    final_reply = await run_llm_generation(
        constraint_prompt=core_result["constraint_prompt"],
        dialogue_history=request.dialogue_history
    )

    pipeline_controller.save_state()

    # ---- numpy scalars -> native conversion ----
    def to_native(value):
        if isinstance(value, (np.generic,)):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, dict):
            return {k: to_native(v) for k, v in value.items()}
        if isinstance(value, list):
            return [to_native(v) for v in value]
        return value

    response_data = {
        "alice_response": final_reply,
        "constraint_prompt": core_result["constraint_prompt"],
        "core_signals": to_native(core_result["signals"]),
        "debug_info": {
            "mediator_out": to_native(core_result["debug_mediator"]),
            "core_output": to_native(core_result["debug_core_output"])
        }
    }

    return JSONResponse(content=response_data)
