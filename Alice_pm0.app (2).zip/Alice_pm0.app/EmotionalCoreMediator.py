import numpy as np
import json
from typing import Dict, Tuple, Optional, Union

class EmotionalCoreMediator:
    """
    ±0理論の情動コアに、環境因子ベクトル ($\mathbf{\eta}_m, \mathbf{h}_k$) と
    知的創造性スコア ($\mathbf{S}_{\text{C}}$) の両方を入力として提供する統合仲介コードクラス。

    環境因子のSDE動態と、創造性スコアの非線形計算ロジックをすべて内包する。
    """

    # --- 1. 環境因子 SDE パラメータと範囲 (EmotionalEnvironmentGeneratorより) ---
    ALPHA_ETA = 2.0  # 快適因子 回帰速度
    ALPHA_HK = 1.5   # 不幸因子 回帰速度
    SIGMA_ETA = 0.5  # 快適因子 ノイズ強度
    SIGMA_HK = 0.5   # 不幸因子 ノイズ強度

    ETA_MIN = 1.0
    ETA_MAX = 5.0
    HK_MIN = 0.2
    HK_MAX = 8.0

    ETA_FACTORS = {
        "S_Consistency": {"index": 0, "is_linear": False, "factor": 4.0},  # m=1, 二次関数
        "S_Freedom": {"index": 1, "is_linear": False, "factor": 4.0},      # m=2, 二次関数
        "S_Equality": {"index": 2, "is_linear": True, "factor": 4.0},      # m=3, 比例関数
    }

    HK_FACTORS = {
        "S_Dominance": {"index": 0, "is_linear": False, "factor": 7.8},      # k=1, 二次関数
        "S_Ethics/Coercion": {"index": 1, "is_linear": False, "factor": 7.8}, # k=2, 二次関数
        "S_Illogicality": {"index": 2, "is_linear": False, "factor": 7.8},    # k=3, 二次関数
    }

    # --- 2. 創造性スコア $\mathbf{S}_{\text{C}}$ パラメータ (CreativityScoreCalculatorより) ---
    D_MAX = 1.0
    ALPHA_N = 2.0
    BETA = 0.5
    ALPHA_U = 1.333
    GAMMA = 1.0
    ALPHA_C = 1.0
    RHO_R = 0.3
    R_CORE_MAX = 5.0 # Use(HALM)_Core の最大貢献

    # --- 3. 初期化 ---
    def __init__(self, dt: float = 0.1, rng_seed: Optional[int] = None):
        self.dt = dt
        self.rng = np.random.default_rng(rng_seed)

        # 環境因子状態の初期化
        self.eta_m = np.full(3, self.ETA_MIN, dtype=float)
        self.h_k = np.full(3, self.HK_MIN, dtype=float)

    # --- 4. 環境因子 $\mathbf{\eta}_m, \mathbf{h}_k$ 駆動ロジック ---

    def _score_to_eta_target(self, score: float, factor_config: Dict) -> float:
        """ 快適因子スコア -> 目標値 $\eta_{m, bar}$ 変換 """
        score = max(0.0, min(1.0, score))
        f_S = score if factor_config["is_linear"] else score ** 2
        return self.ETA_MIN + factor_config["factor"] * f_S

    def _score_to_hk_target(self, score: float, factor_config: Dict) -> float:
        """ 不幸因子スコア -> 目標値 $h_{k, bar}$ 変換 """
        score = max(0.0, min(1.0, score))
        g_S = score ** 2
        return self.HK_MIN + factor_config["factor"] * g_S

    def _step_sde(self, prev_state: np.ndarray, target_state: np.ndarray, alpha: float, sigma: float) -> np.ndarray:
        """
        Euler-Maruyama法によるSDEの1ステップ計算。
        $$X^{\text{new}} = X^{\text{prev}} + \alpha (X_{\text{bar}} - X^{\text{prev}}) dt + \sigma \sqrt{dt} Z$$
        """
        drift = alpha * (target_state - prev_state) * self.dt
        noise = sigma * np.sqrt(self.dt) * self.rng.normal(size=prev_state.shape)
        return prev_state + drift + noise

    def update_environment(self, scores: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        """ 環境因子のSDEステップを実行 """

        # I. 平均回帰目標値の算出
        eta_target = np.empty(3)
        for name, config in self.ETA_FACTORS.items():
            score = scores.get(name, 0.0)
            eta_target[config["index"]] = self._score_to_eta_target(score, config)

        hk_target = np.empty(3)
        for name, config in self.HK_FACTORS.items():
            score = scores.get(name, 0.0)
            hk_target[config["index"]] = self._score_to_hk_target(score, config)

        # II. SDEステップの実行
        self.eta_m = self._step_sde(
            prev_state=self.eta_m, target_state=eta_target, alpha=self.ALPHA_ETA, sigma=self.SIGMA_ETA
        )
        self.h_k = self._step_sde(
            prev_state=self.h_k, target_state=hk_target, alpha=self.ALPHA_HK, sigma=self.SIGMA_HK
        )

        # III. 許容範囲へのクリッピング (ここでは明示的に記述しないが、通常は必要に応じて適用)
        # self.eta_m = np.clip(self.eta_m, self.ETA_MIN, self.ETA_MAX)
        # self.h_k = np.clip(self.h_k, self.HK_MIN, self.HK_MAX)

        return self.eta_m, self.h_k

    # --- 5. 創造性スコア $\mathbf{S}_{\text{C}}$ 計算ロジック ---

    def _calculate_novelty(self, D_t: float) -> float:
        """ 新規性 $\mathbf{N}(t)$ """
        D_t = max(0.0, min(self.D_MAX, D_t))
        novelty = 1.0 + self.ALPHA_N * (D_t ** 2)
        return min(3.0, novelty)

    def _calculate_utility(self, U_now: float, U_future: float) -> float:
        """ 有用性 $\mathbf{U}(t)$ """
        U_now = max(0.0, min(1.0, U_now))
        U_future = max(0.0, min(1.0, U_future))
        utility_sum = U_now + self.BETA * U_future
        utility = 1.0 + self.ALPHA_U * utility_sum
        return min(3.0, utility)

    def _calculate_contribution(self, C_Alice: float, C_Dev: float) -> float:
        """ 自己貢献度 $\mathbf{C}(t)$ """
        C_Alice = max(0.0, min(1.0, C_Alice))
        C_Dev = max(0.0, min(1.0, C_Dev))
        contribution_sum = C_Alice + self.GAMMA * C_Dev
        contribution = 1.0 + self.ALPHA_C * contribution_sum
        return min(3.0, contribution)

    def _calculate_internal_reference(self, Use_HALM_Core: float, RefDegree_LLM: float) -> float:
        """ 内部参照度 $\mathbf{R}(t)$ """
        Use_HALM_Core = max(0.0, min(self.R_CORE_MAX, Use_HALM_Core))
        RefDegree_LLM = max(0.0, min(1.0, RefDegree_LLM))

        # LLM自身の内省度を R_CORE_MAX (5.0) にスケーリング
        Use_LLM_Self = self.R_CORE_MAX * RefDegree_LLM

        Total_Use = Use_HALM_Core + Use_LLM_Self

        R_t = self.RHO_R * Total_Use
        return min(3.0, R_t)

    def calculate_sc(self, raw_inputs: Dict[str, float]) -> Dict[str, float]:
        """
        創造性スコア $\mathbf{S}_{\text{C}}(t)$ とその乗法要素を計算する。
        $$\mathbf{S}_{\text{C}}(t) = \mathbf{N}(t) \times \mathbf{U}(t) \times \mathbf{C}(t) + \mathbf{R}(t)$$
        """
        N_t = self._calculate_novelty(D_t=raw_inputs.get('D_t', 0.0))
        U_t = self._calculate_utility(
            U_now=raw_inputs.get('U_now', 0.0), U_future=raw_inputs.get('U_future', 0.0)
        )
        C_t = self._calculate_contribution(
            C_Alice=raw_inputs.get('C_Alice', 0.0), C_Dev=raw_inputs.get('C_Dev', 0.0)
        )
        # Use_HALM_Core はシステム側 (Alice_pm0.pyのステップなど) で計算されることを想定
        R_t = self._calculate_internal_reference(
            Use_HALM_Core=raw_inputs.get('Use_HALM_Core', 0.0),
            RefDegree_LLM=raw_inputs.get('RefDegree_LLM', 0.0)
        )

        S_C_t = N_t * U_t * C_t + R_t

        return {
            "S_C": S_C_t,
            "N": N_t,
            "U": U_t,
            "C": C_t,
            "R": R_t
        }

    # --- 6. 統合メイン処理 ---

    def process_all_inputs(self, llm_scores_json: str, system_inputs: Dict[str, float]) -> Dict[str, Union[np.ndarray, float]]:
        """
        すべての外部入力を処理し、情動コアに渡す環境因子と創造性スコアを生成する。
        """
        try:
            llm_scores_dict = json.loads(llm_scores_json)
        except json.JSONDecodeError:
            print("ERROR: LLM score JSON format is invalid. Using default scores and previous state.")
            llm_scores_dict = {} # 処理を継続するため空の辞書を使用

        # 1. 環境因子の更新 (LLM評価から)
        eta_m_new, h_k_new = self.update_environment(llm_scores_dict)

        # 2. 創造性スコアの計算 (LLM評価とシステム入力を統合)
        combined_inputs = {**llm_scores_dict, **system_inputs}

        sc_results = self.calculate_sc(combined_inputs)

        return {
            "eta_m_new": eta_m_new,              # キー名をコアの定義に合わせる
            "h_k_new": h_k_new,                  # キー名をコアの定義に合わせる
            "creativity_score_sc": sc_results["S_C"], # キー名をコアの定義に合わせる
            "debug_N": sc_results["N"],
            "debug_U": sc_results["U"],
            "debug_C": sc_results["C"],
            "debug_R": sc_results["R"],
        }